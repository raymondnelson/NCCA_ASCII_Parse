# fix non-ASCII characters in text files
# changed this script to a function 10-4-2016
# raymond nelson
#####

fixNonASCIICharactersFn <- function(searchPattern) {
  # function to fix non ASCII characters in NCCA ASCII text files 
  # non-Enlgish characters
  # x input is a character string to identify the NCCA ASCII text files
  ####
  
  fileNames <- list.files(pattern = searchPattern)
  
  for (i in 1:length(fileNames)) {
    x <- readLines(fileNames[i], encoding="latin1")
    
    x[1:100] <- iconv(x[1:100], "latin1", "ASCII", sub="_")
    
    writeLines(x, fileNames[i])
    
  }
  
  # rm(x)
  # rm(fileNames)
  # rm(i)
  
  return(fileNames)
} # end fixNonASCIICharactersFn() 

# fixNonASCIICharactersFn(searchPattern)
