# 10-27-2015 Raymond Nelson
# 10-29-2015 fixed NA problem


# dataVector <- segmentDF$c_UPneumo[responseOnsetRow:responseEndRow]
# verbalAnswer <- which(segmentDF$Event=="answerRow") - (which(segmentDF$Event=="onsetRow")+1) + 1


# maxPeakPn <- function(x, y=40, firstLast=FALSE) {
#   # helper function to get the positive slope peaks from the pneumo time series data
#   # will keep the index number of max peak samples
#   # x input is a time series vector
#   # y input is the number of offset samples 
#   # xOut is a vector of peak indices to compute the cyclic rate or interpolate the line
#   xOut <- rep(NA, times=(length(x)))
#   if(firstLast==TRUE){
#     xOut[1] <- 1 # keep the first
#     xOut[length(xOut)] <- length(xOut) # keep the last
#   }
#   # buffer will be double the offset value
#   input_buffer <- x[2:(2*y+1)]
#   for (i in 2:(length(x)-(2*y))) {
#     input_buffer <- c(input_buffer[2:(2*y)], x[i+(2*y)])
#     # check to see if the middle value of the buffer is the max
#     ifelse(input_buffer[(y+1)]==max(input_buffer),
#            xOut[i+y+1] <- c(i+y+1), # +1 because we started at 2
#            next()
#     ) # end if
#   } # end for loop
#   return(as.numeric(na.omit(xOut)))
# }  # end maxPeakPn function


##########################################


pneumoMeasurementFn <- function(dataVector, verbalAnswer) {
  # function to compute a pneumo excursion measurement
  # called by the pneumoExtractFn()
  
  # intended to be more robust against common answer distortion artifacts
  # may also be made more robust against 
  # other identified respiration artifacts
  
  # Respiratory excursion is the sum of 
  # the absolute difference of all successive respiration samples.
  
  # The robust excursion measurement is achieved by removing 
  # the data from 2 sec before to 2 sec after 
  # the point of verbal answer, and can be made more robust by 
  # removing other identified artifact segments 
  # from the input data vector.
  
  # A dimensionally stable measurement can be obtained by 
  # summing the excursion lengths for each 1 second period,
  # using a moving window across measurement period,
  # and then taking the mean of the 1 sec excursion lengths 
  # using only the non-artifacted sample differences.
  
  # 2021-08-27 may be more stable by averaging not summing
  
  # This provides a measurement that is dimensionally standarized
  # across a range of possible measurement periods. 
  
  # input dataVector is the time series data for 15 seconds
  # input verbalAnswer is the sample index where the verbal answer is located
  
  # cps is a scalar in the global env including the data sampling rate
  # cps = 30 (30 samples per second x 15 = 450 samples)
  
  # excursion is the sum of absolute differences in y-axis change
  # for each successive sample
  
  # output RExcursion is the mean of excursion lengths 
  # of the moving window across the 15 sec measurement period
  # excluding the samples surrounding the verbal answer 
  
  ####
  
  # compute the absolute difference in respiratory excursion
  REVector1 <- c(0, abs(diff(dataVector))) 
  
  if(!is.null(verbalAnswer))  {
    
    # set the buffer around the verbal answer 
    # pneumoAnsBuff is set the NCCAASCII_init.R script
    ansBufferOn <- verbalAnswer - (pneumoAnsBuff * cps) 
    ansBufferOff <- verbalAnswer + (pneumoAnsBuff * cps) # + 1 
    # 2021-8-27 not sure why the +1 sec
    
    # to work effectively with missed ans key during stim presentation
    if(ansBufferOn < 1) ansBufferOn <- 1 
    if(ansBufferOff > length(dataVector)) ansBufferOff <- length(dataVector)
    
    # set the answer buffer to 0 to prevent measurement and extraction of the answer seg
    # use of 0 during the 1 sec prior to verbal answer will prevent NAs until 1 second prior 
    # REVector1[ansBufferOn:(verbalAnswer-1)] <- 0 
    # REVector1[ansBufferOn:(ansBufferOn+1*cps-1)] <- 0 
    
    # REVector1[verbalAnswer:ansBufferOff] <- NA 
    
    REVector1[ansBufferOn:ansBufferOff] <- NA
    
    # REVector1[ansBufferOn:ansBufferOff] <- 0 
    
  }
  
  REVector1 <- REVector1[which(!is.na(REVector1))]
  
  # initialize another vector
  # REVector2 <- NULL
  REVector2 <- rep(NA, length=(length(REVector1) - (pneumoMeasurementBuffer * cps + 1)))
  
  # compute the sum of absolute differences for the moving window
  # moving window is determined by pneumoMeasurementBuffer in the NCCAASCII_init.R script
  # pneumoMeasurementBuffer <- 1
  i=1
  for (i in 1:length(REVector2)) {
    # REVector2 <- c( REVector2, sum( REVector1[ i:(i+1*cps-1) ] ) )
    REVector2[i] <-  sum( REVector1[i:(i+(pneumoMeasurementBuffer*cps)-1)] )
    # any sum that includes an NA input value will be NA
    # this will ensure that artifacted segments are not included
  } 
  
  # ts.plot(REVector2)
  
  # remove NA sums
  # REVector3 <- REVector2[!is.na(REVector2)] 
  # could be done without defining a new vector
  # and the mean of REVector3 
  # REVector4 <- mean(REVector3)

  # output
  # if(is.null(RExcursion)) RExcursion <- REVector4 
  # return(RExcursion)
  
  # return( mean(REVector2[!is.na(REVector2)]) )
  
  return( mean(REVector2) )
  
} # end pneumoMeasurementFn() function


# pneumoMeasurementFn(dataVector, verbalAnswer)

#############################





###########



# # function to compute the sum of absolute differences in y axis exursion
# pneumoExtract <- function(x, y) {
#   # function to extract the excursion length measurement from pneumo data
#   # x = vector of time series data for the measured stimulus segment
#   # y = time series vector of events for the measured stimulus segment 
#   # including "resonseOnsetRow" "responseEndRow" "aBuffOn" and "aBuffOff"
#   responseOnsetRow <- x[which(x=="responseOnsetRow")]
#   responseEndRow <- x[which(x=="responseEndRow")]
#   aBuffOn <- x[which(x=="aBuffOn")]
#   aBuffOf <- x[which(x=="aBuffOff")]
#   x <- x[c(responseOnsetRow:aBuffOn, aBuffOff:responseEndRow)]
#   return(sum(abs(diff(x))))  
# } # end pneumoExtract function
# 
# # pneumoExtract()

