# R function to write the exams from the global env to NCCA ASCII format
# 2020-02-08
# Raymond Nelson

####



# rm(list=ls())


# setwd("~/Dropbox/DATASETS/LEPET/LEPET_NCCAASCII")


# requires each exam saved as .Rda by the NCCA ASCII part script



{
  library(readr)
  library(stringr)
}


{
  
  RPath <- "~/Dropbox/"
  
  source(paste0(RPath, 'R/NCCA_ASCII_Parse/workFlow_init.R'), echo=FALSE)
  
  # initialize the setColRange() function and the getFirstLastEventFn()
  source(paste0(RPath, 'R/NCCA_ASCII_Parse/sigProcHelper.R'), echo=FALSE)
  
  source(paste0(RPath, 'R/NCCA_ASCII_Parse/NCCAASCII_PseudoNamer.R'), echo=FALSE)
  
  # correct the header details in NCCA ASCII text files
  source(paste0(RPath, 'R/NCCA_ASCII_Parse/NCCAASCII_FixHeaders.R'), echo=FALSE)
  
  # source the sigProcHelper.R script for the getFirstLastEventFn
  source('~/Dropbox/R/NCCA_ASCII_Parse/sigProcHelper.R', echo=FALSE)
  
  # initialize the function to write the NCCA ASCII files
  source(paste0(RPath, 'R/NCCA_ASCII_Parse/NCCAASCII_writer.R'), echo=FALSE)
  # source('~/Dropbox/R/NCCA_ASCII_Parse/NCCAASCII_writer.R')
  
  source(paste0(RPath, 'R/NCCA_ASCII_Parse/excludedEvents.R'), echo=FALSE)
  
  source(paste0(RPath, 'R/NCCA_ASCII_Parse/getExamNames.R'), echo=TRUE)
  
}


#### set the output directory ####

{
  # dirName <- paste0("NCCAASCIIOutputLAF", setNumber)
  dirName <- "NCCAASCIIOutputLAF"
  if( basename(getwd()) != dirName ) {
    if( !dir.exists(dirName) ) dir.create(dirName)
    # setwd(dirName)
  }
  print(paste("output directory:", dirName))

  print(paste("current directory:", basename(getwd())))
  # outputNames <- "FZCT_001"
  
  # outputNames <- paste0("FZCT_2020SD_", str_pad(examNumbers, 3, "left", pad="0"))
  
  # print(outputNames)
  
  
  # private function to located the _Data data frame objects
  # getUniqueExams <- function(x="*_Data$") { unique(str_sub(ls(pattern=x, pos=1),1, -6)) }
  # uniqueExams <- getUniqueExams(x="*_Data$")
  
  
  # # get exam names from the _Data data frames
  # print("make a list of unique exams in the global environment")
  # uniqueExams <- unique(str_sub(ls(pattern="*_Data$", pos=1),1, -6))
  # print(uniqueExams)
}

######## set up some parameters ########

{
  
  # if(!exists("uniqueExams")) uniqueExams <- x
  
  # if(!exists("outputFolderName")) outputFolderName <- "NCCAASCIIOutputLAF"
  if(!exists("outputFolderName")) outputFolderName <- dirName
  
  # check that the output folder exists
  if(!dir.exists(outputFolderName)) dir.create(outputFolderName)
  
  if(!exists("fixLabels")) fixLabels <- FALSE
  if(!exists("fixRQRotation")) fixRQRotation <- FALSE
  if(!exists("fixCQRotation")) fixCQRotation <- FALSE
  if(!exists("fixQuestionLength")) fixQuestionLength <- FALSE
  if(!exists("fixAnswerDistance")) fixAnswerDistance <- FALSE
  
  # fix RQ and CQ labels
  fixLabels <- FALSE
  
  # standardized the RQ and CQ rotations
  fixRQRotation <- FALSE
  fixCQRotation <- FALSE
  
  # adjust the question length and answer distance 
  fixQuestionLength <- FALSE
  fixAnswerDistance <- FALSE
  
  # introduce small variation into question onset, end, and answer locations
  ditherEvents <- FALSE
  
  if(isTRUE(ditherEvents)) {
    fixLabels <- FALSE
    fixRQRotation <- FALSE
    fixCQRotation <- FALSE
    fixQuestionLength <- FALSE
    fixAnswerDistance <- FALSE
  }
  
}

#### warning level ####

{
  # set the warn level to suppress warnings
  if(!exists("oldw")) oldw <- getOption("warn")
  # -1 to suppress warnings
  # 0 is normal, warnings are display at end
  # 1 warnings are display at the time
  # 2 warnings are escalated to errors
  options(warn = 2)
  # options(warn = 0)
  # rm(oldw)
  print(paste("old warn level:", oldw))
  print(paste("current warn level: ", getOption("warn")))
}

#### private function to reduce the measurements data frame to a stimuli data frame ####

{
  
  # private function
  uniqueEventsFn <- function(x) {
    # reduce the measurements data frame to a Stimuli data frame
    # x input is the eventDF
    # output is the eventDF with reduced columns
    eventDF <- x[,1:8]
    theseEvents <- apply(eventDF, 1, paste, collapse="")
    theseEvents <- 
      which(theseEvents[2:length(theseEvents)] != theseEvents[1:(length(theseEvents)-1)])
    theseEvents <- c(1, theseEvents+1)
    eventDF <- eventDF[theseEvents,]
    return(eventDF)
  }
  
}

#### load the exams from the cwd ####

{
  # load the 2.Rda files from the cwd
  theseRDAs <- list.files(pattern="2.Rda$")
  print(theseRDAs)
  i=1
  for(i in 1:length(theseRDAs)) {
    # load(theseRDAs[i])
  }
}

#### call a function to generate new randomized case output names ####

{
  
  {
    # source(paste0(RPath, 'R/NCCA_ASCII_Parse/NCCAASCII_PseudoNamer.R'), echo=TRUE)
    # set.seed(20210218)
    set.seed(20211208)
    
    # outputNames <- NCCAASCCINamerFn(60)
    # outputNames <- outputNames[1:15]
    # outputNames <- outputNames[9]
  }
  
  {
    # re-write the NCCA ASCII files to the same exam names
    
    # may include the $$ character for axciton
    # outputNames <- uniqueExamNames
    
    # does not include $$ character
    outputNames <- uniqueExams
    
    # use the name without the "D"
    # outputNames <- str_sub(uniqueExams, 2, -1)
    
    # uniqueExams2 <- str_sub(uniqueExams, 2, -1)
    
    # outputNames <- uniqueExamNames
    
    # print(outputNames)
  }
  
  {
    # # pad with $ for axciton files
    # i=1
    # for (i in 1:length(outputNames)) {
    #   outputNames[i] <- 
    #     paste0(paste(rep("$", times=(8 - nchar(outputNames[i]))), collapse=""),
    #            outputNames[i])
    # }
    # print(outputNames)
  }
  
  {
    # # source(paste0(RPath, 'R/NCCA_ASCII_Parse/NCCAASCII_PseudoNamer.R'), echo=TRUE)
    # set.seed(20210218)
    # outputNames <- NCCAASCCINamerFn(60)
    # outputNames <- outputNames[16:25]
    # outputNames <- outputNames[2]
    # print(outputNames)
    # 
    # 
    # uniqueExams <- unique(str_sub(ls(pattern="*_Data$", pos=1),1, -6))
    # print(uniqueExams)
    
    # x=uniqueExams
    # y=100
    # showNames=TRUE
    # output=FALSE
    
    # outputNames <- paste0("FZCT_N60_", str_pad(1:10, 3, "left", pad="0"))
    # outputNames <- paste0("SPOT_", str_pad(1:1, 3, "left", pad="0"))
    # outputNames <- "FZCT_001"
    # outputNames <- "FZCT2020D076A"
  }
  
  print(unique(outputNames))
  
}



######## fix the criterion state data frame ########



{
  
  if(!exists("criterionStateDF")) {
    if(file.exists("criterionState.csv")) {
      criterionStateDF <- read_csv("./criterionState.csv")
    }
  }
  
  if(exists("criterionStateDF")) {
    
    criterionStateDFNew <- criterionStateDF
    
    i=1
    for (i in 1:length(uniqueExams)) {
      # uniqueExams[i]  
      thisRow <- which(criterionStateDF$examName ==  str_sub(uniqueExams[i], 2, -1))
      criterionStateDFNew$examName[thisRow] <- outputNames[i]
    }
    
    # View(criterionStateDFNew)
    
    criterionStateDFNew$newExamName <- criterionStateDFNew$examName
    
    write_csv(criterionStateDFNew, 
              paste0("./", outputFolderName, "/", "criterionState.csv"))
    
  }
  
}



########################################################################

##########  write the NCCA ASCII output to Lafayette format ############


# set to false so this script does not run unintentionally
if(!exists("writeNCAAASCII_LAF")) writeNCAAASCII_LAF <- FALSE
# writeNCAAASCII_LAF <- TRUE


if(isTRUE(writeNCAAASCII_LAF)) {
  
  #### get the exams from the global env ####
  
  {
    # get exam names from the _Data data frames in the global envir
    print("make a list of unique exams in the global environment")
    uniqueExams <- unique(str_sub(ls(pattern="*_Data$", pos=1),1, -6))
    print(uniqueExams)
    
    
    # source the getExamNames.R script to load and call the getCharts() function
    # source(paste0(RPath, 'R/NCCA_ASCII_Parse/getExamNames.R'), echo=TRUE)
    
    uniqueExamNames <- getCharts(x="D&-", uniqueTests=TRUE)
    # uniqueExamNames <- getCharts(x="D%-", uniqueTests=TRUE)
    # uniqueExamNames <- getCharts(x="D\\$-", uniqueTests=TRUE)
    print(uniqueExamNames)
  }
  
  #### set the output names ####
  
  {
    
    # different method to get the output names
    # if(file.exists("criterionState.csv")) {
    #   criterionState <- read_csv("criterionState.csv")
    #   # View(criterionState)
    #   outputNames <- criterionState$examName
    #   
    #   print(outputNames)
    # }
    
    # write the .csv with the old names and new names
    # oldNameNewNameDF <- 
    #   cbind.data.frame(oldName=uniqueExams, newName=outputNames, examName=uniqueExamNames)
    # write_csv(oldNameNewNameDF, paste0("oldNameNewName_", length(outputNames), ".csv"))
    
    # dirName <- "testDir"
    # if(!dir.exists("./testDir")) dir.create("testDir")
    # setwd(dirName)
    
    
    # if(!exists("setNumber")) setNumber <- ""
    
    if(length(uniqueExams) != length(outputNames)) {
      stop("unequal lengths: check the length of the outputNames vector ")
    }
    
  }
  
   ######## set up the exam names and series name ###########
  
  {
    
    if(!exists("outputNames")) outputNames <- uniqueExams
    
    print(outputNames)
    
  }
  
  ######## set the series name ########
  
  {
    
    if(!exists("outputSeriesName")) outputSeriesName <- "2"
    
    outputSeriesName <- "2"
    # outputSeriesName <- "X"
    
    print(paste("output series name:", outputSeriesName))
    
  }
  
  ######## set the output sensors ########
  
  {
    if(!exists("outputSensors")) outputSensors <- c("UPneumo", "LPneumo", "EDA1", "Cardio1", "Move1", "PPG1")
    if(is.null(outputSensors)) outputSensors <- c("UPneumo", "LPneumo", "EDA1", "Cardio1", "Move1", "PPG1")
    
    # inclPPG <- FALSE
    if(!exists("inclPPG")) inclPPG <- TRUE
    
    print(paste("output sensors:", paste(outputSensors, collapse=" ")))
  }
  
  #### iterate over the exams and write the NCCA ASCII output ####
  
  # source('~/Dropbox/R/NCCA_ASCII_Parse/NCCAASCII_writer.R')
  # this function will call another function from the NCCAASCII_writer.R script
  
  i=1
  for(i in 1:length(uniqueExams)) {
    
    {
      # get the data frame with the times series data
      
      examName <- uniqueExams[i]
      assign("examName", examName, pos=1)
      print(examName)
      print(paste(i, "of", length(uniqueExams)))
      
      # get the names of time series lists for all unique series in each exam
      # searchString <- paste0("*", examName, "_Data", "*")
      
      # get the time series data frame for the exam
      # examDF <- get(glob2rx(searchString, trim.head=TRUE, trim.tail=TRUE), pos=1)
      
      # instead get the data from the input vector of exam names
      examDF <- get(paste0(examName, "_Data"), pos=1)
      
      # set the first and last rows
      examOnsetRow <- 1
      examEndRow <- nrow(examDF)
      
      # print(examName)
      
      # get the stimulus events data frame for the exam
      
      # eventDFName <- paste0(examName, "_Stimuli")
      eventDFName <- paste0(examName, "_Measurements")
      if(exists(eventDFName)) {
        eventDF <- get(eventDFName, pos=1)
        eventDF <- eventDF[,1:8]
        # reduce the measurements data frame to a Stimuli data frame
        eventDF <- uniqueEventsFn(eventDF)
      } 
      
      # View(eventDF)
      
      {
        # change the data types - this should be done during parsing for efficiency
        # eventDF$seriesName <- as.character(eventDF$seriesName)
        # eventDF$Event <- as.numeric(eventDF$Event)
        # eventDF$Begin <- as.numeric(eventDF$Begin)
        # eventDF$End <- as.numeric(eventDF$End)
        # eventDF$Answer <- as.numeric(eventDF$Answer)
      }
      
      # reassign the _Stimuli and eventDF data frames
      # assign(paste0(examName, "_Stimuli"), eventDF, pos=1)
      # assign("eventDF", eventDF, pos=1)
      # View(eventDF)
      
      # get the names of unique series
      uniqueSeries <- as.character(unique(examDF$seriesName))
      print(paste("unique series: ", uniqueSeries))
      
      # initialize a newEventDF for this exam
      newEventDF <- NULL
      
    }
    
    ##### set the base questions lengths #####
    
    {
      
      # initialize the stimulus lengths here so that they are similar for each chart
      # initialize the new RQ and CQ lengths - this can be 4 RQs regardless of 
      RQLengths <- round(sample(c((2.5*cps):(3.25*cps)), 5, replace=TRUE))
      CQLengths <- round(sample(c((3*cps):(3.75*cps)), 5, replace=TRUE))
      
      # RQLengths 
      # CQLengths
      
      SALength <- round(sample(c((3.25*cps):(4.25*cps)), 1))
      
      # symptomatic lengths - also introductory question
      SYLengths <- round(sample(c((3.25*cps):(3.75*cps)), 3, replace=TRUE))
      
      # neutral question lengths
      NLengths <- round(sample(c((1.75*cps):(2.25*cps)), 3, replace=TRUE))
      
      # X and XX announcement lengths
      XXXLengths <- round(sample(c((3*cps):(4*cps)), 2, replace=TRUE))
    
    }
    
    #### iterate over each unique series ####
    
    j=1
    for(j in 1:length(uniqueSeries)) {
      
      {
        # get the time-series data frame for this series
        seriesName <- uniqueSeries[j]
        seriesRows <- which(examDF$seriesName == seriesName)
        # seriesOnsetRow <- which(examDF$seriesName == seriesName)[1]
        # seriesEndRow <- seriesOnsetRow + nrow(seriesDF) - 1
        seriesOnsetRow <- min(seriesRows)
        seriesEndRow <- max(seriesRows)
        seriesDF <- examDF[seriesRows,]
        # View(seriesDF)
        
        assign("seriesDF", seriesDF, pos=1)
        assign("seriesName", seriesName, pos=1)
        
        print(paste("series:", toString(seriesName)))
        
        # get a vector of names of time series data for the charts in the exam series
        uniqueCharts <- as.character(unique(seriesDF$chartName))
        print(paste("unique charts:", toString(uniqueCharts)))
        
        # outputSeriesName <- "2"
        outputSeriesName <- seriesName
        
        # outputSeriesName <- NULL
        if(is.null(outputSeriesName)) {
          # use the series number if the outputSeriesName is NULL
          outputSeriesName2 <- j
        } else {
          # use the input param if not NULL
          outputSeriesName2 <- outputSeriesName
        }
      }
      
      ##### iterate over each chart in the series #####
      
      k=1
      for(k in 1:length(uniqueCharts)) {
        
        {
          # get the chart and chart details
          
          chartName <- uniqueCharts[k]
          assign("chartName", chartName, pos=1)
          print(paste("chart name:", chartName))
          
          # get the data frame with the time series data for each chart in the series
          chartRows <- which(seriesDF$chartName==chartName)
          # chartOnsetRow <- which(seriesDF$chartName==chartName)[1]
          # chartEndRow <- chartOnsetRow + nrow(chartDF) - 1
          # chartEndRow <- max(which(seriesDF$chartName==chartName))
          chartOnsetRow <- min(chartRows)
          chartEndRow <- max(chartRows)
          
          chartDF <- seriesDF[chartRows,]
          assign("chartDF", chartDF, pos=1)
          # View(chartDF)
        }
        
        # get the first and last events
        
        # {
        #   # source the sigProcHelper.R script for the getFirstLastEventFn
        #   # source('~/Dropbox/R/NCCA_ASCII_Parse/sigProcHelper.R', echo=FALSE)
        #   
        #   firstLastEvents <- getFirstLastEventFn(x=chartDF)
        #   firstEvent <- firstLastEvents[1]
        #   lastEventEnd <- firstLastEvents[2] - 450
        #   lastEvent <- firstLastEvents[2] - 450
        #   assign("firstLastEvents", firstLastEvents, pos=1)
        # }
        
        ####### planned action here #######
        
        ##### slice a chart events data frame for the events in this chart #####
        
        {
          theseEventRows <- which(eventDF$seriesName == seriesName & 
                                    eventDF$chartName == chartName)
          thisChartEventsDF <- eventDF[theseEventRows,]
          # View(thisChartEventsDF)
          assign("thisChartEventsDF", thisChartEventsDF, envir=.GlobalEnv)
        }
        
        #####  slice a data frame for the time series data for this chart #####
        
        {
          # a vector of sensors to be included in the NCCA ASCII output
          # outputSensors2 <- c("UPneumo", "LPneumo", "EDA1", "Cardio1", "Move1", "PPG1")
          outputSensors2 <- outputSensors
          
          # remove the PLE sensor if not present
          if(!("PPG1" %in% names(chartDF))) {
            outputSensors2 <- outputSensors[c(1, 2, 3, 4, 5)]
          }
          
          # use the input parameter to exclude the PPG
          if(!isTRUE(inclPPG)) {
            outputSensors2 <- outputSensors[c(1, 2, 3, 4, 5)]
          }
          
          # View(chartDF)
          
          # column numbers for the output sensors
          theseSensorCols <- which(names(chartDF) %in% outputSensors)
          # names(chartDF)[theseSensorCols]
          
          # names(chartDF)[theseSensorCols]
          
          # rearrange the sensor columns
          theseSensorCols2 <- theseSensorCols
          n=1
          for(n in 1:length(theseSensorCols2)) {
            theseSensorCols2[n] <- 
              theseSensorCols[which(names(chartDF)[theseSensorCols] == outputSensors[n])]
          }
          
          # slice a chart data frame to work with
          # the first 10 cols are exam, series, chart and event info
          thisChartDF <- chartDF[,c(1:10, theseSensorCols2)]
          
          assign("thisChartDF", thisChartDF, envir=.GlobalEnv)
          # View(thisChartDF)
        }
        
        ##### vary the lengths of the questions for this chart #####
        
        {
          RQLengths2 <- RQLengths + sample(c(-4:4), size=length(RQLengths), replace=TRUE)
          
          CQLengths2 <- CQLengths + sample(c(-4:4), size=length(CQLengths), replace=TRUE)
   
          SALength2 <- SALength + sample(c(-4:4), size=length(SALength), replace=TRUE)
          
          SYLengths2 <- SYLengths + sample(c(-4:4), size=length(SYLengths), replace=TRUE)
          
          NLengths2 <- NLengths + sample(c(-4:4), size=length(NLengths), replace=TRUE)
          
          XXXLengths2 <- XXXLengths + sample(c(-4:4), size=length(XXXLengths), replace=TRUE)
        }
        
        ##### construct the new chart name #####
        
        {
          newChartName <- paste0(str_pad(k, 2, "left", pad="0"), "A" )
          
          print(paste("new chart name:", newChartName))
        }
        
        ##### construct the NCCA ASCII output file name #####
        
        {
          outputNameI <- outputNames[i]
          
          # if(exists("criterionState")) {
          #   outputNameI <- 
          #     criterionState$examName[which(criterionState$AxExamName==uniqueExams2[i])]
          # }  
          
          thisOutputName <- paste0(str_sub(outputNameI, 1, -1),
                                   # str_sub(outputNames[i], 1, -1),
                                   "-",
                                   # "2", # series number
                                   outputSeriesName2,
                                   ".", 
                                   # chart name in NCCA form ex: "01A"
                                   newChartName )
          assign("thisOutputName", thisOutputName, envir=.GlobalEnv)
          
          print(paste("output file name:", thisOutputName))
          
          # "D&-" will be added by the NCCAASCII_writer function
        }
        
        ##### call a function to write the NCCA ASCII file #####
        
        # source('~/Dropbox/R/NCCA_ASCII_Parse/NCCAASCII_writer.R')
        
        writeNCCAASCIIFn(thisChartDF=thisChartDF, 
                         thisChartEventsDF=thisChartEventsDF,
                         newChartName=newChartName,
                         thisOutputName=thisOutputName,
                         outputSensors2=outputSensors2,
                         outputSeriesName2=outputSeriesName2,
                         inclPPG=inclPPG,
                         inclAutoEDA=TRUE,
                         fixAnswerDistance=fixAnswerDistance,
                         fixLabels=fixLabels,
                         fixRQRotation=fixRQRotation,
                         fixCQRotation=fixCQRotation,
                         fixQuestionLength=fixQuestionLength,
                         fixDuplicates=TRUE,
                         RQLengths2=RQLengths2,
                         CQLengths2=CQLengths2,
                         SALength2=SALength2,
                         SYLengths2=SYLengths2,
                         NLengths2=NLengths2,
                         XXXLengths2=XXXLengths2,
                         ditherEvents=ditherEvents,
                         outputFolderName=outputFolderName )
        
      } # end for loop over each k chart
      
      # chartDF was submitted to the examDF in the inner loop
      
    } # end for loop over each j series
    
    # no need to submit the seriesDF to the examDF
    
  } # end for loop over i unique exam names
  
  print(paste(i, "exams processed"))
  
  print(outputNames)
  
  # setwd("./NCCAASCIIOutputLAF")
   
  
  ####
  
  # reset the warn level
  if(exists("oldw")) options(warn = oldw)
  
  
  # initialize the name of the csv file to hold the old and new names
  # setNumber <- "_set9"
  # setNumber <- ""
  # csvName <- paste0("FZCT_SD2020", setNumber, ".csv")
  # csvName <- paste0("AFMGQT_LEPET", setNumber, ".csv")
  
  
  # examNumbers <- c(87:87)
  
  
  # write the csv with old name and new exam name
  # write_csv(cbind.data.frame(uniqueExams, outputNames), csvName)
  
  
  # set to false so this script does not run unintentionally
  writeNCAAASCII_LAF <- FALSE
  
  
} # end isTRUE(reWriteNCAAASCII_LAF)



 # reWriteNCAAASCII_LAF <- TRUE
# setNumber <- "_set2"
# csvName <- paste0("FZCT_SD2020", "_set2", ".csv")
# examNumbers <- c(11:20)



# setwd("~/Dropbox/CURRENT_PROJECTS/Algorithm Comparison - Handler 2020/data/FZCT_N60/NCCA_ASCII_OSS3_holdoutN60/NCCAASCIIOutputLAF")
