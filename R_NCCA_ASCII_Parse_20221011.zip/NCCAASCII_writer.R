# R function to export the test chart data to NCCA ASCII format
# 14 Dec 2018
# Raymond Nelson
#
##########



# library(stringr)


{
  
  # source(paste0(RPath, 'R/NCCA_ASCII_Parse/NCCAASCII_PseudoNamer.R'))
  
  # source the NCCA ASCII parse helper function to load the fromMinSec function
  source(paste0(RPath, 'R/NCCA_ASCII_Parse/toMinSec.R'), echo=FALSE)
  
  # initialize the setColRange() function and the getFirstLastEventFn()
  source(paste0(RPath, 'R/NCCA_ASCII_Parse/sigProcHelper.R'), echo=FALSE)
  
}


# writeNCCAASCII <- TRUE


# examName <- "TES1"
# seriesName <- "1"
# chartName <- "01A"

writeNCCAASCIIFn <- function(thisChartDF=thisChartDF, 
                             thisChartEventsDF=thisChartEventsDF,
                             newChartName=newChartName,
                             thisOutputName=thisOutputName,
                             outputSensors2=NULL,
                             outputSeriesName2=NULL,
                             inclPPG=TRUE,
                             inclAutoEDA=TRUE,
                             fixAnswerDistance=FALSE,
                             fixLabels=FALSE,
                             fixRQRotation=FALSE,
                             fixCQRotation=FALSE,
                             fixQuestionLength=FALSE,
                             fixDuplicates=FALSE,
                             RQLengths2=RQLengths2,
                             CQLengths2=CQLengths2,
                             SALength2=SALength2,
                             SYLengths2=SYLengths2,
                             NLengths2=NLengths2,
                             XXXLengths2=XXXLengths2,
                             ditherEvents=FALSE,
                             outputFolderName="NCCAASCIIOutputLAF" ) {
  # R function to write the NCCA ASCII file for each chart
  # 2020-02-08
  # Raymond Nelson
  #
  # called by the NCCAASCIIOutputFn() in the NCCAASCCIIOutput.R script
  #
  # thisChartDF is the data frame for a single chart
  # thisChartEventsDF is the events data frame for a single chart
  #
  # thisOutputName is the output file name in NCCA ASCII format
  #
  # ouput sensors2 is a vector of NCCA ASCII sensor names
  # outputSeriesName2 is the output series name to use in the file names
  # inclPPG will include or exclude the PPG sensor
  #
  # fixRQRotation can be used to set the RQ rotation for each chart
  # fixCQRotation can be used to set the CQ rotation for each chart
  # fixLabels can be use to set the CQ and RQ labels 
  #
  # visible output is the name of the exam 
  # for which the NCCA ASCII files are written
  #
  # NCCA ASCII output is to the CWD
  #
  ####
  
  {
    
    ### set up ###
    
    # assign("thisChartDF", thisChartDF, envir=.GlobalEnv)
    # assign("thisChartEventsDF", thisChartEventsDF, envir=.GlobalEnv)

    # stop("writing NCCA ASCII")
    
    if(!exists("outputSeriesName2")) outputSeriesName2 <- NULL
    outputSeriesName2 <- as.character(outputSeriesName2)
    if(length(outputSeriesName2) == 0) outputSeriesName2 <-
      as.character(thisChartDF$seriesName[1])
    
    if(!exists("outputSensors2")) outputSensors2 <-c("UPneumo", "LPneumo", "EDA1", "Cardio1", "Move1")
    if(is.null(outputSensors2)) outputSensors2 <- c("UPneumo", "LPneumo", "EDA1", "Cardio1", "Move1")
    
    if(!exists("inclPPG")) inclPPG <- TRUE
    
    
    
    # check if PLE data are available
    if(("PPG1" %in% names(thisChartDF)) && inclPPG) {
      inclPPG2 <- TRUE
    } else {
      inclPPG2 <- FALSE
    }
    
    if(isTRUE(inclPPG)) outputSensors2 <- c(outputSensors2, "PPG1")
    
    if(isTRUE(inclAutoEDA)) outputSensors2 <- c(outputSensors2, "EDA2")
    
    if(!exists("fixRQRotation")) fixRQRotation <- FALSE
    if(!exists("fixCQRotation")) fixCQRotation <- FALSE
    if(!exists("fixLabels")) fixLabels <- FALSE
    if(!exists("fixAnswerDistance")) fixAnswerDistance <- FALSE
    if(!exists("fixQuestionLength")) fixQuestionLength <- FALSE
    
    if(!exists("outputFolderName")) outputFolderName <- "NCCAASCIIOutputLAF"
    
    if(!exists("newChartName")) newChartName <- thisChartDF$chartName[1] # "03A"
      
    print(paste("exam:", thisChartDF$examName[1]))
    
  }
  
  #### Construct the output name ####
  
  {
    
    # outputNames[i]
    
    if(!exists("thisOutputName")) {
      thisOutputName <- paste0(str_sub(thisChartDF$examName[1], 2, -1),
                               "-",
                               # "2", # series number
                               outputSeriesName2,
                               ".",
                               # chart name in NCCA form ex: "01A"
                               newChartName )
    }
      
    # thisOutputName <- paste0(outputNames[i], 
    #                          "-",
    #                          # "2", # series number
    #                          outputSeriesName,
    #                          ".", 
    #                          # chart name in NCCA form ex: "01A"
    #                          newChartName )
    
    
    
    # show the NCCAASCII text file name on the console
    print(paste("write the NCCA ASCII file:", thisOutputName))
    
  }
  
  #### set the chart time ####
  
  {
    
    thisSeriesNumber <- as.numeric(str_sub(thisOutputName, -5, -5))
    thisChartNumber <- as.numeric(str_sub(thisOutputName, -2, -2))
    # thisChartTime <- c("01:01", "02:01", "03:01", "04:01", "05:01", "06:01", "07:01", "08:01", "09:01")[thisChartNumber]
    # thisChartTime <- c("12:01", "12:16", "12:31", "12:46", "12:01", "12:16", "02:31", "02:46", "03:01")[thisChartNumber]
    
    seriesNumbers <- c("01", "02", "03", "04", "05")
    chartTimes <- c(":10", ":20", ":30", ":40", ":50")
  
    thisChartTime <- paste0(seriesNumbers[thisSeriesNumber], chartTimes[thisChartNumber])  
    
  }
  
  #### scale the data for output to the NCCA ASCII format ####
  
  {
    
    {
      ### get the first and last event locations ###
      
      # source the sigProcHelper.R script for the getFirstLastEventFn
      # source('~/Dropbox/R/NCCA_ASCII_Parse/sigProcHelper.R', echo=FALSE)
      
      firstLastEvents <- getFirstLastEventFn(thisChartDF)
      firstEvent <- firstLastEvents[1]
      lastEventEnd <- firstLastEvents[2]
    }
    
    # use a function to scale the data
    for(l in 11:ncol(thisChartDF)) {
      thisChartDF[,l] <- 
        setColRange(x=thisChartDF[,l], 
                    y=250000, 
                    firstRow=firstEvent, 
                    lastRow=lastEventEnd)
    }
    
    # offset the data and round to .0 decimals
    for(l in 11:ncol(thisChartDF)) {
      # offsetVal <- 25000 - median((thisChartDF[,l]))
      # offsetVal <- 10000 - min(thisChartDF[,l] )
      offsetVal <- 30000 - min(thisChartDF[,l][firstEvent:lastEventEnd] )
      thisChartDF[,l] <- round(thisChartDF[,l] + offsetVal, 0)
    }
    
    # adjust values less than 1 or greater than 999999
    for(l in 11:ncol(thisChartDF)) {
      thisChartDF[,l][which(thisChartDF[,l] < 1)] <- 1
      thisChartDF[,l][which(thisChartDF[,l] > 999999)] <- 999999
    }
    
    # fix the sample numbers
    thisChartDF$Sample <- 1:nrow(thisChartDF)
    
    {
      # for inspection only, not used for output
      
      assign("thisChartDF", thisChartDF, envir=.GlobalEnv)
      # stop()
      # View(thisChartDF)
    }
    
  }
  
  ######################################################
  
  #### check and fix some problems with the answers ####
  
  {
    # check for answers that are equal to the End
    fixThese <- which(thisChartEventsDF$Answer == thisChartEventsDF$End)
    if(length(fixThese) > 0) {
      fixChartDFRows <- as.numeric(thisChartEventsDF$Answer[fixThese])
      # first work with the data
      # set the Label to the preceding row before fixing the Label
      thisChartDF$Label[fixChartDFRows] <- thisChartDF$Label[(fixChartDFRows - 1)]
      thisChartDF$Label[(fixChartDFRows + 1)] <- "ANS"
      # then fix the events data frame
      thisChartEventsDF$Answer[fixThese] <- (fixChartDFRows + 1)
    }
    # View(thisChartEventsDF)
  }
  
  {
    # check that annotations occur on a single row with no answer
    # remove verbal answers for annotation in the events data frame
    annotationRows <- which(thisChartEventsDF$Begin == thisChartEventsDF$End)
    # delete the answer row
    if(length(annotationRows > 0)) {
      # delete the answers from the time series data
      for(o in 1:length(annotationRows)) {
        # fix the time series data first
        thisDataRow <- as.numeric(thisChartEventsDF$Answer[annotationRows[o]])
        thisChartDF$Label[thisDataRow] <- ""
      }
      # delete the answers in the events data frame
      thisChartEventsDF$Answer[annotationRows] <- ""
    }
  }
  
  {
    # check for and fix missing answers to test questions
    # includes X and XX and annotations for now, and these are removed later
    fixThese <-
      which(thisChartEventsDF$Answer[1:nrow(thisChartEventsDF)] == "")
    # add 1 for the X
    fixThese <- fixThese
    # remove annotations on a single row using the annotationRows vector
    if(length(annotationRows > 0)) {
      fixThese <- fixThese[-which(fixThese %in% annotationRows)]
    }
    # set the missing answers
    if(length(fixThese) > 0) {
      # randomize the answer distance from .67 to 1.5 seconds after stim end
      spoofAns <- sample(c(67:45), size=length(fixThese))
      theseChartDFRows <- as.numeric(thisChartEventsDF$End[fixThese]) + spoofAns
      # add the missing answer to the events DF
      thisChartEventsDF$Answer[fixThese] <- theseChartDFRows
      # add the missing answer to the data 
      thisChartDF$Label[theseChartDFRows] <- "ANS"
    }
  }
  
  #### check the answer distance for RQs and CQs and other questions ####
  
  if(isTRUE(fixAnswerDistance)) {    
    # check the answer distance for all events except X and XX
    # annotations will give distance == NA because of no answers
    chartDFOffsetRows <- 
      as.numeric(thisChartEventsDF$End[1:nrow(thisChartEventsDF)])
    chartAnswerRows <- 
      as.numeric(thisChartEventsDF$Answer[1:nrow(thisChartEventsDF)])
    answerDistance <- chartAnswerRows - chartDFOffsetRows
    fixThese <- which(answerDistance < 20 | answerDistance > 38)
    # exclude X and XX answers
    fixThese <- fixThese[!(fixThese %in% c(1,nrow(thisChartEventsDF)))]
    # fixThese is offset by 1 row because started at 2
    if(length(fixThese) > 0) {
      # get the old answer rows in the data
      oldAnswerRows <- as.numeric(thisChartEventsDF$Answer[fixThese])
      # Clear the answer in the events data frame
      thisChartEventsDF$Answer[fixThese] <- ""
      # sample a new distance from .67 to 1.25 seconds.
      answerDistance[fixThese] <- 
        sample(c(20:38), size=length(fixThese), replace=TRUE)
      # get the new answer rows
      newAnswerRows <- chartDFOffsetRows[fixThese] + answerDistance[fixThese]
      # set the new answer location in the events data frame
      thisChartEventsDF$Answer[fixThese] <- newAnswerRows
      # clear the answer in the times series data frame for this chart
      thisChartDF$Label[oldAnswerRows] <- ""
      # set the new answer in the time series data
      thisChartDF$Label[newAnswerRows] <- "ANS"
    }
    # View(thisChartEventsDF)
    # View(thisChartDF)
    # check other questions 
  }
  
  #### check for and remove answers for annotations ####
  
  {
    # annotations have end == begin, so they have a single row
    # annotations have no answer in the NCCA ASCII output

    # locate the events for which the end == begin and delete the answer
    fixThese <- which(thisChartEventsDF$Begin == thisChartEventsDF$End)
    fixThese2 <- which(thisChartEventsDF$Begin == thisChartEventsDF$End - 1)
    fixThese <- sort(c(fixThese, fixThese2))
    if(length(fixThese) > 0) {
      o=1
      for(o in 1:length(fixThese)) {
        # fix the answer in the time series data first
        thisDataRow <- as.numeric(thisChartEventsDF$Answer[fixThese[o]])
        thisChartDF$Label[thisDataRow] <- ""
        # then fix the answer in the events data frame
        thisChartEventsDF$Answer[fixThese[o]] <- ""
        # fix the end in the data and events data frame
        thisDataRow <- as.numeric(thisChartEventsDF$Begin[fixThese[o]]) + 1
        thisChartDF$Label[thisDataRow]
        thisChartEventsDF$End[fixThese[o]] <- thisChartEventsDF$Begin[fixThese[o]]
        
      }
    }
  }
  
  #### check the label for R10 because some people use 0 and "O" carelessly ####
  
  {
    # check the label for question 10 - some people use "O" instead of 0
    fixThese <- which(thisChartEventsDF$Label %in% c("1OR", "R1O"))
    if(length(fixThese) > 0) {
      theseRowsStart <- thisChartEventsDF$Begin[fixThese]
      theseRowsEnd <- thisChartEventsDF$End[fixThese] 
      o=1
      if( !is.na(fixThese[1] == "") ) {
        for(o in 1:length(fixThese)) {
          if(fixThese[o] == "") next()
          correctLabel <- ifelse(thisChartEventsDF$Label[fixThese[o]] == "1OR", 
                                 "10R", 
                                 "R10" )
          thisChartEventsDF$Label[fixThese[o]] <- correctLabel
          thisChartDF$Label[theseRowsStart[o]:theseRowsEnd[o]] <- correctLabel
        }
      }
    }
  }
  
  #### Sept 21, 2021 Check and fix the Sacrifice Question Labels ####
  
  # {
  #   # for all exams
  #   fixThese <- grep(pattern="2", x=thisChartEventsDF$Label)
  #   if(length(fixThese) > 0) {
  #     theseRowsStart <- thisChartEventsDF$Begin[fixThese]
  #     theseRowsEnd <- thisChartEventsDF$End[fixThese] 
  #     o=1
  #     if( !is.na(fixThese[1] == "") ) {
  #       for(o in 1:length(fixThese)) {
  #         if(fixThese[o] == "") next()
  #         thisChartEventsDF$Label[fixThese[o]] <- "SA2"
  #         thisChartDF$Label[theseRowsStart[o]:theseRowsEnd[o]] <- "SA2"
  #       }
  #     }
  #   }
  # }
  
  #### Sept 21, 2021 Check and fix the Introductory Question Labels ####
  
  # {
  #   # for Utah exams
  #   fixThese <- 2 # Int question is always 2nd after the X announcement
  #   if(length(fixThese) > 0) {
  #     theseRowsStart <- thisChartEventsDF$Begin[fixThese]
  #     theseRowsEnd <- thisChartEventsDF$End[fixThese] 
  #     o=1
  #     if( !is.na(fixThese[1] == "") ) {
  #       for(o in 1:length(fixThese)) {
  #         if(fixThese[o] == "") next()
  #         thisChartEventsDF$Label[fixThese[o]] <- "Int1"
  #         thisChartDF$Label[theseRowsStart[o]:theseRowsEnd[o]] <- "Int1"
  #       }
  #     }
  #   }
  # }
  
  #### Sept 21, 2021 Check and fix the question Label for symptomatic 3 ####
  
  # {
  #   # for all FZCT and BiZone
  #   fixThese <- grep(pattern="3", x=thisChartEventsDF$Label)
  #   fixThese2 <- grep(pattern="C", x=thisChartEventsDF$Label)
  #   fixThese <- fixThese[which(!(fixThese %in% fixThese2))]
  #   if(length(fixThese) > 0) {
  #     theseRowsStart <- thisChartEventsDF$Begin[fixThese]
  #     theseRowsEnd <- thisChartEventsDF$End[fixThese] 
  #     o=1
  #     if( !is.na(fixThese[1] == "") ) {
  #       for(o in 1:length(fixThese)) {
  #         if(fixThese[o] == "") next()
  #         thisChartEventsDF$Label[fixThese[o]] <- "E3"
  #         thisChartDF$Label[theseRowsStart[o]:theseRowsEnd[o]] <- "E3"
  #       }
  #     }
  #   }
  # }
  
  #### Sept 21, 2021 Check and fix the question Label for symptomatic 8 ####
  
  # {
  #   # for all FZCT and BiZone
  #   fixThese <- grep(pattern="8", x=thisChartEventsDF$Label)
  #   fixThese2 <- grep(pattern="C", x=thisChartEventsDF$Label)
  #   fixThese <- fixThese[which(!(fixThese %in% fixThese2))]
  #   fixThese2 <- grep(pattern="R", x=thisChartEventsDF$Label)
  #   fixThese <- fixThese[which(!(fixThese %in% fixThese2))]
  #   if(length(fixThese) > 0) {
  #     theseRowsStart <- thisChartEventsDF$Begin[fixThese]
  #     theseRowsEnd <- thisChartEventsDF$End[fixThese] 
  #     o=1
  #     if( !is.na(fixThese[1] == "") ) {
  #       for(o in 1:length(fixThese)) {
  #         if(fixThese[o] == "") next()
  #         thisChartEventsDF$Label[fixThese[o]] <- "E8"
  #         thisChartDF$Label[theseRowsStart[o]:theseRowsEnd[o]] <- "E8"
  #         # needs to be E9 for BiZone
  #       }
  #     }
  #   }
  # }
  
  #### Sept 21, 2021 Check and fix the question Label for Neutral 1 questions ####
  
  # {
  #   # for all FZCT and BiZone
  #   fixThese <- grep(pattern=c("1"), x=thisChartEventsDF$Label)
  #   fixThese2 <- grep(pattern="C", x=thisChartEventsDF$Label)
  #   fixThese <- fixThese[which(!(fixThese %in% fixThese2))]
  #   fixThese2 <- grep(pattern="R", x=thisChartEventsDF$Label)
  #   fixThese <- fixThese[which(!(fixThese %in% fixThese2))]
  #   if(length(fixThese) > 0) {
  #     theseRowsStart <- thisChartEventsDF$Begin[fixThese]
  #     theseRowsEnd <- thisChartEventsDF$End[fixThese] 
  #     o=1
  #     if( !is.na(fixThese[1] == "") ) {
  #       for(o in 1:length(fixThese)) {
  #         if(fixThese[o] == "") next()
  #         thisChartEventsDF$Label[fixThese[o]] <- "N1"
  #         thisChartDF$Label[theseRowsStart[o]:theseRowsEnd[o]] <- "N1"
  #       }
  #     }
  #   }
  # }
  
  #### Sept 21, 2021 Check and fix the question Label for Neutral 2 questions ####
  
  {
    # # for all DLST and PCAT
    # fixThese <- grep(pattern=c("2"), x=thisChartEventsDF$Label)
    # fixThese2 <- grep(pattern="C", x=thisChartEventsDF$Label)
    # fixThese <- fixThese[which(!(fixThese %in% fixThese2))]
    # fixThese2 <- grep(pattern="R", x=thisChartEventsDF$Label)
    # fixThese <- fixThese[which(!(fixThese %in% fixThese2))]
    # if(length(fixThese) > 0) {
    #   theseRowsStart <- thisChartEventsDF$Begin[fixThese]
    #   theseRowsEnd <- thisChartEventsDF$End[fixThese]
    #   o=1
    #   if( !is.na(fixThese[1] == "") ) {
    #     for(o in 1:length(fixThese)) {
    #       if(fixThese[o] == "") next()
    #       thisChartEventsDF$Label[fixThese[o]] <- "N2"
    #       thisChartDF$Label[theseRowsStart[o]:theseRowsEnd[o]] <- "N2"
    #     }
    #   }
    # }
  }
  
  ###############################################################
  
  #### sept 20, 2021 check the length of CQs and RQs ####
  
  if(isTRUE(fixQuestionLength)) {
    
    RQRows <- grep("R", thisChartEventsDF$Label)
    CQRows <- grep("C", thisChartEventsDF$Label)
    
    # View(thisChartEventsDF)
    
    RQLengths2 <- RQLengths2[1:length(RQRows)]
    CQLengths2 <- CQLengths2[1:length(CQRows)]
    
    RQStart <- as.numeric(thisChartEventsDF$Begin[RQRows])
    RQEnd <- as.numeric(thisChartEventsDF$End[RQRows])
    
    # (RQEnd - RQStart) / cps
    
    CQStart <- as.numeric(thisChartEventsDF$Begin[CQRows])
    CQEnd <- as.numeric(thisChartEventsDF$End[CQRows])
    
    # (CQEnd - CQStart) / cps
    
    oldRQEnd <- as.numeric(thisChartEventsDF$End[RQRows])
    oldCQEnd <- as.numeric(thisChartEventsDF$End[CQRows])
    
    oldRQAnswer <- as.numeric(thisChartEventsDF$Answer[RQRows])
    oldCQAnswer <- as.numeric(thisChartEventsDF$Answer[CQRows])
    
    newRQEnd <- RQStart + RQLengths2 - 1
    newCQEnd <- CQStart + CQLengths2 - 1
    
    # new RQ Answers from .67 to 1.25 seconds
    newRQAnswer <- newRQEnd + sample(c(20:38), size=length(newRQEnd), replace=TRUE)
    # new CQ Answer from .75 to 1.5 seconds
    newCQAnswer <- newCQEnd + sample(c(23:45), size=length(newCQEnd), replace=TRUE)
    
    # adjust the rows and answers in the events data frame
    
    thisChartEventsDF$Answer[RQRows] <-  newRQAnswer
    thisChartEventsDF$Answer[CQRows] <-  newCQAnswer
    
    thisChartEventsDF$End[RQRows] <-  newRQEnd
    thisChartEventsDF$End[CQRows] <-  newCQEnd
    
    # remove the old events and  answers in the time series data
    
    thisChartDF$Label[oldRQAnswer] <- ""
    thisChartDF$Label[oldCQAnswer] <- ""
    
    # thisChartDF$Label
    
    # iterate over the RQs and CQs to fix the questions
    
    o=1
    for(o in 1:length(RQStart)) {
      thisChartDF$Label[RQStart[o]:oldRQEnd[o]] <- ""
      thisChartDF$Label[RQStart[o]:newRQEnd[o]] <-  thisChartEventsDF$Label[RQRows][o]
    }
    
    o=1
    for(o in 1:length(CQStart)) {
      thisChartDF$Label[CQStart[o]:oldCQEnd[o]] <- ""
      thisChartDF$Label[CQStart[o]:newCQEnd[o]] <-  thisChartEventsDF$Label[CQRows][o]
    }
    
    thisChartDF$Label[newRQAnswer] <- "ANS"
    thisChartDF$Label[newCQAnswer] <- "ANS"
    
    # add the adjusted events and answer to the time series data
    
    RQLabels <- thisChartEventsDF$Label[RQRows]
    CQLabels <- thisChartEventsDF$Label[CQRows]
    
    # View(thisChartEventsDF)
    
    # eventLabel column is not used for output to NCCA ASCII
    
  }
  
  #### check the length of the Sacrifice Question ####
  
  if(isTRUE(fixQuestionLength)) {
    
    # View(thisChartEventsDF)
    SAQuestions <- c("SA2", "2SA")
    SARows <- which(thisChartEventsDF$Label %in% SAQuestions)
    
    SALength2 <- SALength2[1:length(SARows)]
    
    SAStart <- as.numeric(thisChartEventsDF$Begin[SARows])
    SAEnd <- as.numeric(thisChartEventsDF$End[SARows])
    
    # (SAEnd - SAStart) / cps
    
    oldSAEnd <- as.numeric(thisChartEventsDF$End[SARows])
    
    oldSAAnswer <- as.numeric(thisChartEventsDF$Answer[SARows])
    
    newSAEnd <- SAStart + SALength2 - 1
    
    # new Answers from .67 to 1.25 seconds
    newSAAnswer <- newSAEnd + sample(c(20:38), size=length(newSAEnd), replace=TRUE)
    # adjust the rows and answers in the events data frame
    
    thisChartEventsDF$Answer[SARows] <-  newSAAnswer
    
    thisChartEventsDF$End[SARows] <-  newSAEnd
    
    # remove the old events and  answers in the time series data
    
    thisChartDF$Label[oldSAAnswer] <- ""
    
    # thisChartDF$Label
    
    # iterate over the SA questions to fix the questions
    
    o=1
    for(o in 1:length(SAStart)) {
      thisChartDF$Label[SAStart[o]:oldSAEnd[o]] <- ""
      thisChartDF$Label[SAStart[o]:newSAEnd[o]] <-  thisChartEventsDF$Label[SARows][o]
    }
    
    thisChartDF$Label[newSAAnswer] <- "ANS"
    
    # add the adjusted events and answer to the time series data
    
    SALabels <- thisChartEventsDF$Label[SARows]
    # View(thisChartEventsDF)
    
    # eventLabel column is not used for output to NCCA ASCII
    
  }
  
  #### check the length of the Introductory and Symptomatic Questions ####
  
  if(isTRUE(fixQuestionLength)) {
    
    # View(thisChartEventsDF)
    SYQuestions <- c("Int", "Int1", "1Int", "3E", "E3", "8E", "E8", "I1")
    OQRows <- which(thisChartEventsDF$Label %in% SYQuestions)
    
    SYLengths2 <- SYLengths2[1:length(OQRows)]
    
    OQStart <- as.numeric(thisChartEventsDF$Begin[OQRows])
    OQEnd <- as.numeric(thisChartEventsDF$End[OQRows])
    
    # (OQEnd - OQStart) / cps
    
    oldOQEnd <- as.numeric(thisChartEventsDF$End[OQRows])
    
    oldOQAnswer <- as.numeric(thisChartEventsDF$Answer[OQRows])
    
    newOQEnd <- OQStart + SYLengths2 - 1
    
    # new Answers from .67 to 1.25 seconds
    newOQAnswer <- newOQEnd + sample(c(20:38), size=length(newOQEnd), replace=TRUE)
    # adjust the rows and answers in the events data frame
    
    thisChartEventsDF$Answer[OQRows] <-  newOQAnswer
    
    thisChartEventsDF$End[OQRows] <-  newOQEnd
    
    # remove the old events and  answers in the time series data
    
    thisChartDF$Label[oldOQAnswer] <- ""
    
    # thisChartDF$Label
    
    # iterate over the Int nd SY questions to fix the questions
    
    o=1
    for(o in 1:length(OQStart)) {
      thisChartDF$Label[OQStart[o]:oldOQEnd[o]] <- ""
      thisChartDF$Label[OQStart[o]:newOQEnd[o]] <-  thisChartEventsDF$Label[OQRows][o]
    }
    
    thisChartDF$Label[newOQAnswer] <- "ANS"
    
    # add the adjusted events and answer to the time series data
    
    OQLabels <- thisChartEventsDF$Label[OQRows]
    # View(thisChartEventsDF)
    
    # eventLabel column is not used for output to NCCA ASCII
    
  }
  
  #### check the length of Neutral Questions ####
  
  if(isTRUE(fixQuestionLength)) {
    
    # View(thisChartEventsDF)
    
    {
      NQuestions <- c("N1", "1N", "N2", "2N", "7N", "N7")
      NQuestions <- c(NQuestions, c("1N1", "1N2", "1N3", "1N4"))
      NQuestions <- c(NQuestions, c("2N1", "2N2", "2N3", "2N4"))
      NQuestions <- c(NQuestions, c("3N1", "3N2", "3N3", "3N4"))
      NQuestions <- c(NQuestions, c("4N1", "4N2", "4N3", "4N4"))
    }
    
    NQRows <- which(thisChartEventsDF$Label %in% NQuestions)
    
    NLengths2 <- NLengths2[1:length(NQRows)]
    
    NQStart <- as.numeric(thisChartEventsDF$Begin[NQRows])
    NQEnd <- as.numeric(thisChartEventsDF$End[NQRows])
    
    # (NQEnd - NQStart) / cps
    
    oldNQEnd <- as.numeric(thisChartEventsDF$End[NQRows])
    
    oldNQAnswer <- as.numeric(thisChartEventsDF$Answer[NQRows])
    
    newNQEnd <- NQStart + NLengths2 - 1
    
    # new Answers from .67 to 1.25 seconds
    newNQAnswer <- newNQEnd + sample(c(20:38), size=length(newNQEnd), replace=TRUE)
    # adjust the rows and answers in the events data frame
    
    thisChartEventsDF$Answer[NQRows] <-  newNQAnswer
    
    thisChartEventsDF$End[NQRows] <-  newNQEnd
    
    # remove the old events and  answers in the time series data
    
    thisChartDF$Label[oldNQAnswer] <- ""
    
    # thisChartDF$Label
    
    # iterate over the Int SA and SY questions to fix the questions
    
    o=1
    for(o in 1:length(NQStart)) {
      thisChartDF$Label[NQStart[o]:oldNQEnd[o]] <- ""
      thisChartDF$Label[NQStart[o]:newNQEnd[o]] <-  thisChartEventsDF$Label[NQRows][o]
    }
    
    thisChartDF$Label[newNQAnswer] <- "ANS"
    
    # add the adjusted events and answer to the time series data
    
    NQLabels <- thisChartEventsDF$Label[NQRows]
    # View(thisChartEventsDF)
    
    # eventLabel column is not used for output to NCCA ASCII
    
  }
  
  #### check the length of the X and XX announcements  ####
  
  if(isTRUE(fixQuestionLength)) {
    
    # View(thisChartEventsDF)
    XXXQuestions <- c("X", "XX")
    XXXRows <- which(thisChartEventsDF$Label %in% XXXQuestions)
    
    XXXLengths2 <- XXXLengths2[1:length(XXXRows)]
    
    XXXStart <- as.numeric(thisChartEventsDF$Begin[XXXRows])
    XXXEnd <- as.numeric(thisChartEventsDF$End[XXXRows])
    
    # (XXXEnd - XXXStart) / cps
    
    oldXXXEnd <- as.numeric(thisChartEventsDF$End[XXXRows])
    
    oldXXXAnswer <- as.numeric(thisChartEventsDF$Answer[XXXRows])
    
    newXXXEnd <- XXXStart + XXXLengths2 - 1
    
    # new Answers from .67 to 1.25 seconds
    newXXXAnswer <- newXXXEnd + sample(c(20:38), size=length(newOQEnd), replace=TRUE)
    # adjust the rows and answers in the events data frame
    
    {
      # NO ANSWERS FOR X AND XX ANNOUNCEMENTS 
      
      thisChartEventsDF$Answer[XXXRows] <-  ""
      
      # thisChartEventsDF$End[XXXRows] <-  newXXXEnd
    }
    
    # remove the old events and  answers in the time series data
    
    thisChartDF$Label[oldXXXAnswer] <- ""
    
    # thisChartDF$Label
    
    # iterate over the Int X AND XX announcements to fix the questions
    
    o=1
    for(o in 1:length(XXXStart)) {
      thisChartDF$Label[XXXStart[o]:oldXXXEnd[o]] <- ""
      thisChartDF$Label[XXXStart[o]:newXXXEnd[o]] <-  thisChartEventsDF$Label[XXXRows][o]
    }
    
    # NO ANSWER FOR X AND XX announcements
    # thisChartDF$Label[newOQAnswer] <- "ANS"
    
    # add the adjusted events and answer to the time series data
    
    XXXLabels <- thisChartEventsDF$Label[XXXRows]
    # View(thisChartEventsDF)
    
    # eventLabel column is not used for output to NCCA ASCII
    
  }
  
  ########### dithering response onset, end, and answer ###################
  
  if(isTRUE(ditherEvents)) {
    
    # introduce small variation to the begin, end and answer locations
    
    oldBeginIdx <- as.numeric(thisChartEventsDF$Begin)
    oldEndIdx <- as.numeric(thisChartEventsDF$End)
    oldAnswerIdx <- as.numeric(thisChartEventsDF$Answer)
    
    eventLabel <- thisChartEventsDF$Label
    
    # # exclude annotations (for which there is no verbal answer)
    # oldBeginIdx <- oldBeginIdx[which(oldAnswerIdx != "")]
    # oldEndIdx <- oldEndIdx[which(oldAnswerIdx != "")]
    # eventLabel <- eventLabel[which(oldAnswerIdx != "")]
    # 
    # oldAnswerIdx <- oldAnswerIdx[which(oldAnswerIdx != "")]
    
    # answers
    o=1
    for(o in 1:length(eventLabel)) {
      # next if no answer
      if(oldAnswerIdx[o] == "" || is.na(oldAnswerIdx[o])) next()
      if(eventLabel[o] == "") next()
      answerWord <- thisChartDF$Label[as.numeric(oldAnswerIdx[o])]
      newIdx <- as.numeric(oldAnswerIdx[o]) + sample(c(-3:3), 1)
      if(as.numeric(oldAnswerIdx[o]) <= (as.numeric(oldEndIdx[o])+1)) next()
      if(newIdx < (oldEndIdx[o]+20)) { newIdx <- oldEndIdx[o]+20 }
      thisChartDF$Label[as.numeric(oldAnswerIdx[o])] <- ""
      thisChartDF$Label[newIdx] <- answerWord
      thisChartEventsDF$Answer[o] <- newIdx
    }
    
    # Begin
    o=1
    for(o in 1:length(eventLabel)) {
      # next if no answer
      if(oldAnswerIdx[o] == "" || is.na(oldAnswerIdx[o])) next()
      oldBegin <- oldBeginIdx[o]
      newBegin <- oldBegin + sample(c(-4:4), 1)
      if(newBegin <= oldBegin) {
        thisChartDF$Label[newBegin:oldBegin] <- thisChartDF$Label[oldBegin]
      } else {
        thisChartDF$Label[(oldBegin:(newBegin-1))] <- ""
      }
      thisChartEventsDF$Begin[o] <- newBegin
    }
    
    # end
    for(o in 1:length(eventLabel)) {
      # next if no answer
      if(oldAnswerIdx[o] == "" || is.na(oldAnswerIdx[o])) next()
      oldEnd <- oldEndIdx[o]
      newEnd <- oldEnd + sample(c(-3:3), 1)
      if(as.numeric(oldAnswerIdx[o]) <= (oldEndIdx[o]+1)) next()
      if(newEnd >= oldEnd) {
        thisChartDF$Label[oldEnd:newEnd] <- thisChartDF$Label[oldEnd]
      } else {
        thisChartDF$Label[((newEnd+1):oldEnd)] <- ""
      }
      thisChartEventsDF$End[o] <- newEnd
    }
    
  }
  
  #######################################################
  
  #### ensure that RQ and CQ answers are "NO" ####
  
  {  
    # check the answers for RQ, CQ and other questions 
    RQRows <- grep("R", thisChartEventsDF$Label)
    CQRows <- grep("C", thisChartEventsDF$Label)
    RQCQRows <- sort(c(RQRows, CQRows))
    # answer rows in the chart time series data frame
    RQCQChartDFAnswerRows <- as.numeric(thisChartEventsDF$Answer[RQCQRows])
    # fix RQ and CQ answers that are not NO
    fixThese <- which(thisChartDF$Label[RQCQChartDFAnswerRows] != "NO")
    if(length(fixThese) > 0) {
      # does not fix missing answers
      thisChartDF$Label[RQCQChartDFAnswerRows[fixThese]] <- "NO"
    }
  }
  
  #### check the questions with YES answers ####

  {    
    theseQuestions <- c("1", "1A", "1B", "1D", "1E", "2", "3")
    theseQuestions <- c(theseQuestions, c("3E", "E3", "7", "SA", "Int", "I1"))
    theseQuestions <- c(theseQuestions, c("N1", "N2", "N3", "1N", "2N", "3N"))
    # question 8 has a NO answer for Federal ZCT exams 
    # question 8 is neutral and has YES answer for Canadian A Series ZCT
    # theseQuestions <- c(theseQuestions, c("8E", "E8"))
    checkThese <- which(thisChartEventsDF$Label %in% theseQuestions)
    theseRows <- as.numeric(thisChartEventsDF$Answer[checkThese])
    # get the rows to fix in the time series data
    fixThese <-  theseRows[which(thisChartDF$Label[theseRows] != "YES")]
    if(length(fixThese) > 0) {
      thisChartDF$Label[fixThese] <- "YES"
    }
  }
  
  #### check for YES answers for ACQT charts ####
  
  {
    # theseQuestions <- c("1", "2", "3", "4", "4K", "5", "6", "7", "4KA")
    # checkThese <- which(thisChartEventsDF$Label %in% theseQuestions)
    # 
    # # set the answer for YES answer questions
    # theseRows <- as.numeric(thisChartEventsDF$Answer[checkThese])
    # thisChartDF$Label[theseRows] <- "YES"
  }
  
  #### question 8 has a NO answer for Federal ZCT exams ####

  # {
  #   # question 8 is Symptomatic and has a NO answer for Federal ZCT exams
  #   # question 8 is a Neutral for the Canadian ZCT (RCMP/CPC A Series)
  #   theseQuestions <- c("8", "8E", "E8")
  #   checkThese <- which(thisChartEventsDF$Label %in% theseQuestions)
  #   # set the answer for these question
  #   theseRows <- as.numeric(thisChartEventsDF$Answer[checkThese])
  #   thisChartDF$Label[theseRows] <- "NO"
  #   # thisChartDF$Label[checkThese] <- "NO"
  # }
  
  ###########################################
  
  #### question labels for different formats ####

  {  
    
    {
      # initialize a long vector of all RQs and CQs for all test formats 
      # events that are not in this list are annotations without answers
      
      # yes answered questions
      theseQuestions <- c("SA", "SY", "1", "1A", "1B", "1D", "2", "3", "3E", "E3", "4", "7", "8", "8E", "E8")
      theseQuestions <- c(theseQuestions, c("N1", "1N", "N2", "2N", "7N", "N7"))
      theseQuestions <- c(theseQuestions, c("1N1", "1N2", "1N3", "1N4"))
      theseQuestions <- c(theseQuestions, c("2N1", "2N2", "2N3", "2N4"))
      theseQuestions <- c(theseQuestions, c("3N1", "3N2", "3N3", "3N4"))
      theseQuestions <- c(theseQuestions, c("4N1", "4N2", "4N3", "4N4"))
      # other questions for ACQT charts
      theseQuestions <- c(theseQuestions, c("4", "4K", "4KA", "5", "6", "7"))
      # ZCT
      theseQuestions <- c(theseQuestions, c("C4", "4C", "C6", "6C", "C9", "9C"))
      theseQuestions <- c(theseQuestions, c("R5", "5R", "7R", "R7", "10R", "R10"))
      #  procedural questions
      theseQuestions <- c(theseQuestions, c("Int", "Int1", "1Int", "I1", "SA2", "2SA", "3E", "E3", "8E", "E8"))
      # AFMGQT and LEPET
      theseQuestions <- c(theseQuestions, c("C3", "3C", "C5", "5C", "C7", "7C", "C8", "8C", "C9", "9C", "C10", "10C", "C11", "11C", "C12", "12C"))
      theseQuestions <- c(theseQuestions, c("R4", "4R", "R6", "6R", "R8", "8R", "R9", "9R", "R10", "10R", "R11", "11R"))
      # LEPET series 2
      theseQuestions <- c(theseQuestions, c("C23", "23C", "C25", "25C", "C27", "27C", "C28", "28C", "C29", "29C", "C30", "30C", "C31", "31C", "C32", "32C"))
      theseQuestions <- c(theseQuestions, c("R24", "24R", "R26", "26R", "R28", "28R", "R29", "29R", "R30", "30R", "R31", "31R"))
      # UTAH RQs and CQs
      theseQuestions <- c(theseQuestions, c("1C", "C1", "2C", "C2", "3C", "C3"))
      theseQuestions <- c(theseQuestions, c("R1", "1R", "R2", "2R", "R3", "3R", "R4", "4R"))
      # TES/DLST and PCASS/PCAT
      theseQuestions <- c(theseQuestions, c("1R1", "1R2", "1R3", "2R1", "2R2", "2R3", "3R1", "3R2", "3R3", "4R1", "4R2", "4R3"))
      theseQuestions <- c(theseQuestions, c("1C1", "1C2", "1C3", "2C1", "2C2", "2C3", "3C1", "3C2", "3C3", "4C1", "4C2", "4C3"))
    }
  }
  
  ########################################################################
  
  #### check for events that are not questions and remove the answers ####
  
  {
    # questions not in theseQuestions are annotations
    checkThese <- which(!(thisChartEventsDF$Label %in% theseQuestions)) 
    # locate the answers
    theseRows <- as.numeric(thisChartEventsDF$Answer[checkThese])
    theseRows <- theseRows[which(!is.na(theseRows))]
    # get the rows to fix in the time series data
    fixThese <-  theseRows[which(thisChartDF$Label[theseRows] != "")]
    if(length(fixThese) > 0) {
      # first remove the answer in the time series data
      thisChartDF$Label[fixThese] <- ""
      # then remove the answer in the events table
      thisChartEventsDF$Answer[checkThese] <- ""
    }
    
    # thisChartDF$Label[theseRows] <- ""
    # thisChartEventsDF$Answer[checkThese] <- ""
    
  }
  
  #### remove answers to X and XX events ####
  
  {
    # get the X and XX answer rows
    XXXRows <- 
      thisChartEventsDF$Answer[thisChartEventsDF$Label=="X" |
                                 thisChartEventsDF$Label=="XX"]
    XXXRows <- as.numeric(XXXRows[XXXRows != ""])
    
    # check if there are answer labels that are not X or XX
    XXXRows <- XXXRows[!(thisChartDF$Label[XXXRows] %in% c("X", "XX"))]
    if(length(XXXRows) > 0) {
      thisChartDF$Label[XXXRows] <- ""
    }
    
    # set all of the X and XX answers to ""
    thisChartEventsDF$Answer[thisChartEventsDF$Label=="X" |
                               thisChartEventsDF$Label=="XX"] <- ""
    # View(thisChartEventsDF)
  }
  
  #### end check answers ####
  
  ######################################################
  
  #### RQ AND CQ rotation schedule ####
  
  {
    
    # Re-acquire the RQ and CQ rows
    
    # RQ and RQ rows in the events data frame
    RQRows <- grep("R", thisChartEventsDF$Label)
    CQRows <- grep("C", thisChartEventsDF$Label)
    
    # newChartName is the new name of the chart for the output data
    if(!exists("newChartName")) newChartName <- "03A"
    
  }
  
  {
    
    ## CQ Rotation ##
    
    # 3 CQs Federal You-Phase / Bi-Zone
    CQ3RotationBZ <- switch(newChartName,
                            "01A"=c("C4", "C6", "C8"),
                            "02A"=c("C6", "C8", "C4"),
                            "03A"=c("C8", "C4", "C6") )
    # 3 CQs Federal ZCT
    CQ3RotationFZCT <- switch(newChartName,
                              "01A"=c("C4", "C6", "C9"),
                              "02A"=c("C6", "C9", "C4"),
                              "03A"=c("C9", "C4", "C6") ) 
    # 3 CQs Utah 3 Question
    CQ3RotationUT3 <- switch(newChartName,
                             "01A"=c("C4", "C7", "C10"),
                             "02A"=c("C7", "C10", "C4"),
                             "03A"=c("C10", "C4", "C7") ) 
    # 3 CQs Utah 4 Question
    CQ4RotationUT4 <- switch(newChartName,
                             "01A"=c("C4", "C7", "C10"),
                             "02A"=c("C7", "C10", "C4"),
                             "03A"=c("C10", "C4", "C7") ) 
    # 3 CQs AFMGQTV2
    CQ3RotationAF2 <- switch(newChartName,
                             "01A"=c("C3", "C6", "C9"),
                             "02A"=c("C6", "C9", "C3"),
                             "03A"=c("C9", "C3", "C6") ) 
    # 3 CQs AFMGQTV1
    CQ3RotationAF1 <- switch(newChartName,
                             "01A"=c("C3", "C5", "C7"),
                             "02A"=c("C5", "C7", "C3"),
                             "03A"=c("C7", "C3", "C5") )
    # 4 CQs AFMGQTV1
    CQ4RotationAF1 <- switch(newChartName,
                             "01A"=c("C3", "C5", "C7", "C9"),
                             "02A"=c("C5", "C7", "C9", "C3"),
                             "03A"=c("C7", "C9", "C3", "C5") )
    # 5 CQs AFMGQTV1 - with an extract CQ at the end of 4 RQs
    CQ5RotationAF1 <- switch(newChartName,
                             "01A"=c("C3", "C5", "C7", "C9", "C11"),
                             "02A"=c("C5", "C7", "C9", "C11", "C3"),
                             "03A"=c("C7", "C9", "C11", "C3", "C5") )
    # 4 CQs LEPET with inserted 7N
    CQ4RotationLPT <- switch(newChartName,
                             "01A"=c("C3", "C5", "C8", "C10"),
                             "02A"=c("C5", "C10", "C8", "C3"),
                             "03A"=c("C10", "C3", "C5", "C8") )
    # 5 CQs LEPET with inserted 7N
    CQ5RotationLPT <- switch(newChartName,
                             "01A"=c("C3", "C5", "C8", "C10", "C12"),
                             "02A"=c("C5", "C10", "C12", "C8", "C3"),
                             "03A"=c("C10", "C3", "C5", "C12", "C8") )
  
    ## DLST/TES ##
    
    # # TES/DLST with 2 RQs repeated 4 times
    # RQRotation <- c("1R1", "1R2", "2R1", "2R2", "3R1", "3R2", "4R1", "4R2")
    # # TES/DLST with 2 CQs repeated
    CQ2RotationDLST <- c("1C1", "1C2", "2C1", "2C2", "3C1", "3C2", "4C1", "4C2")
    
    ## PCASS/PCAT
    
    # # PCASS/PCAT with 3 RQs repeated 4 times
    # RQRotation <- c("1R1", "1R2", "1R3", "2R1", "2R2", "2R3", "3R1", "3R2", "3R3", "4R1", "4R2", "4R3")
    # # PCASS/PCAT with 2 RQs repeated 4 times
    # RQRotation <- c("1R1", "1R2", "2R1", "2R2", "3R1", "3R2", "4R1", "4R2")
    # # PCASS/PCAT with 3 CQs repeated 4 times
    CQ3RotationPCAT <- c("1C1", "1C2", "1C3", "2C1", "2C2", "2C3", "3C1", "3C2", "3C3", "4C1", "4C2", "4C3")
    CQ2RotationPCAT <- c("1C1", "1C2", "2C1", "2C2", "3C1", "3C2", "4C1", "4C2")
    
    {
      # rotation is based on the number of CQs
      CQRotation <- switch(as.character(length(CQRows)),
                           "3"=CQ3RotationAF2,
                           # "4"=CQ4RotationAF1,
                           "4"=CQ4RotationLPT,
                           "5"=CQ5RotationLPT ) 
    }
    
    {
      CQRotation <- CQ3RotationFZCT
    }

    # {
    #   CQRotation <- CQ3RotationBZ
    # }
    
  }

  {
    
    ## RQ Rotation ##
    
    ## Federal ZCT ##
    
    # RQ rotation for Federal ZCT exams
    RQRotationFZCT <- c("R5", "R7", "R10")
    # RQs are traditionally not rotated for this format
    
    ## Federal You-Phase Bi-Zone ##
    
    # RQ rotation for Federal ZCT exams
    RQRotationFBZ <- c("R5", "R7")
    # RQs are traditionally not rotated for this format
    
    ## AFMGQTv2 ##
    
    # RQ rotation for AFMGQTv2 exams with 2 RQs
    # RQRotation <- c("R4", "R6")
    RQ2RotationAF2 <- switch(newChartName,
                         "01A"=c("R4", "R6"),
                         "02A"=c("R6", "R4"),
                         "03A"=c("R4", "R6") )
    
    # RQ rotation for AFMGQTv2 exams with 3 RQs
    # RQRotation <- c("R4", "R5", "R7")
    RQ3RotationAF2 <- switch(newChartName,
                         "01A"=c("R4", "R5", "R7"),
                         "02A"=c("R7", "R4", "R5"),
                         "03A"=c("R5", "R7", "R4") )
    
    # RQ rotation for AFMGQTv2 exams with 4 RQs
    # RQRotation <- c("R4", "R5", "R7", "R8")
    RQ4RotationAF2 <- switch(newChartName,
                             "01A"=c("R4", "R5", "R7", "R8"),
                             "02A"=c("R7", "R4", "R8", "R5"),
                             # "03A"=c("R5", "R8", "R4", "R7") )
                             "03A"=c("R4", "R5", "R7", "R8") ) 
    
    ## AFMGQT-LEPET ##
    
    # # RQ rotation for AFMGQT-LEPET exams 4 RQs with I7 and 5CQs
    # # RQRotation <- c("R4", "R6", "R9", "R11")
    RQ4RotationLPT <- switch(newChartName,
                         "01A"=c("R4", "R6", "R9", "R11"),
                         "02A"=c("R6", "R9", "R4", "R11"),
                         "03A"=c("R9", "R4", "R6", "R11") )
    
    {
      # RQ rotation is based on the test format and number of RQs
      
      RQRotation <- switch(as.character(length(RQRows)),
                           "2"=RQ2RotationAF2,
                           "3"=RQ3RotationAF2,
                           # "4"=RQ4RotationLPT,
                           "4"=RQ4RotationAF2,
                           "5"=RQ5RotationAF2 )
      
    }
    
    {
      RQRotation <- RQRotationFZCT
    }
    
    # {
    #   RQRotation <- RQRotationFBZ
    # }
    
  }
  
  #### set the RQ and CQ rotation ####
  
  {
    
    if(isTRUE(fixRQRotation)) {
      ## RQ Rotation ##
      
      # set the new RQ rotation in the events data frame
      thisChartEventsDF$Label[RQRows] <- RQRotation

      # use a loop to set the RQ rotation in the time series data frame
      RQRowsStart <- thisChartEventsDF$Begin[RQRows]
      RQRowsEnd <- thisChartEventsDF$End[RQRows]
      o=1
      for(o in 1:length(RQRowsStart)) {
        thisChartDF$Label[RQRowsStart[o]:RQRowsEnd[o]] <- RQRotation[o]
      }
    }
    
    if(isTRUE(fixCQRotation)) {
      ## CQ Rotation ##
      
      # set the new CQ rotation in the events data frame
      thisChartEventsDF$Label[CQRows] <- CQRotation
      
      # use a loop to set the CQ rotation in the time series data frame
      CQRowsStart <- thisChartEventsDF$Begin[CQRows]
      CQRowsEnd <- thisChartEventsDF$End[CQRows]
      o=1
      for(o in 1:length(CQRowsStart)) {
        thisChartDF$Label[CQRowsStart[o]:CQRowsEnd[o]] <- CQRotation[o]
      }
    }
    
  }
  
  #### fix the RQ and CQ labels ####
  
  if(isTRUE(fixLabels)) {
    
    # RQ rows in the events data frame
    RQRows <- grep("R", thisChartEventsDF$Label)
    
    oldRQLabels <- c("R24", "R26", "R28", "R30", "R29", "R31")
    # oldRQLabels <- c(oldRQLabels, c("R8", "R10")) # for LEPET
    newRQLabels <- c("R4", "R6", "R9", "R11", "R9", "R11")
    # newRQLabels <- c(newRQLabels, c("R9", "R11")) # for LEPET
    
    fixTheseRQs <- RQRows[which(thisChartEventsDF$Label[RQRows] %in% oldRQLabels)]
    
    RQRowsBegin <- as.numeric(thisChartEventsDF$Begin[fixTheseRQs])
    RQRowsEnd <- as.numeric(thisChartEventsDF$End[fixTheseRQs])
    
    # CQ Rows in the events data frame
    CQRows <- grep("C", thisChartEventsDF$Label)
    
    oldCQLabels <- c("C23", "C24", "C25", "C26", "C27", "C28", "C29", "C30", "C31", "C32")
    newCQLabels <- c("C3", "C4", "C5", "C6", "C7", "C8", "C9", "C10", "C11", "C12")
    
    fixTheseCQs <- CQRows[which(thisChartEventsDF$Label[CQRows] %in% oldCQLabels)]
    
    CQRowsBegin <- as.numeric(thisChartEventsDF$Begin[fixTheseCQs])
    CQRowsEnd <- as.numeric(thisChartEventsDF$End[fixTheseCQs])
    
    # loop over the RQ labels
    if(length(fixTheseRQs) > 0) {
      o=1
      for(o in 1:length(fixTheseRQs)) {
        oldRQ <- thisChartEventsDF$Label[fixTheseRQs[o]]
        newRQ <- newRQLabels[which(oldRQLabels == oldRQ)]
        # fix the time series data frame first
        thisChartDF$Label[RQRowsBegin[o]:RQRowsEnd[o]] <- newRQ
        # then fix the chart events data frame
        thisChartEventsDF$Label[fixTheseRQs[o]] <- newRQ
      }
    } 
    
    # loop over the CQ labels
    if(length(fixTheseCQs) > 0) {
      # fix the time series data frame first
      o=1
      for(o in 1:length(fixTheseCQs)) {
        oldCQ <- thisChartEventsDF$Label[fixTheseCQs[o]]
        newCQ <- newCQLabels[which(oldCQLabels == oldCQ)]
        # fix the time series data frame first
        thisChartDF$Label[CQRowsBegin[o]:CQRowsEnd[o]] <- newCQ
        # then fix the chart events data frame
        thisChartEventsDF$Label[fixTheseCQs[o]] <- newCQ
      }
    } 
    
    # does not fix the eventLabel column
    # because it is not included in the NCCA ASCII output
    # and these changes are not saved
    
    # View(thisChartEventsDF)
    
  }
  
  #### fix duplicate events ####
  
  if(!exists("fixDuplicates")) fixDuplicates <- TRUE
  
  if(isTRUE(fixDuplicates)) {
    
    o=1
    for(o in 1:nrow(thisChartEventsDF)) {
      
      # check if the Label and eventLabel are identical
      thisChartDF$eventLabel[thisChartEventsDF$Begin[o]:thisChartEventsDF$End[o]] <- 
        thisChartDF$eventLabel[thisChartEventsDF$Begin[o]]
    }
    
    # fix the answers
    theseAnswers <- as.numeric(thisChartEventsDF$Answer[which(thisChartEventsDF$Answer != "")])
    thisChartDF$eventLabel[theseAnswers] <- thisChartDF$Label[theseAnswers]
      
    # ansText <- c("No", "NO", "no", "Yes", "YES", "yes", "Ans", "ANS", "ans")
    
  }
  
  ######################################
  
  #### construct the output names ####
  
  {
    examName <- unique(thisChartDF$examName)[1]
    
    # seriesName <- unique(thisChartDF$seriesName)[1]
    # seriesName <- "2"
    # seriesName <- outputSeriesName2
    
    # chartName <- unique(thisChartDF$chartName)[1]
    # chartName <- newChartName
    
    # initialize the name of the NCCA ASCII Outtput file
    NCCAASCIIName <- paste0("D&-", thisOutputName)
    
    print(paste0("new NCCA ASCII name: ", NCCAASCIIName) )
  }
  
  #### initialize the header info ####
  
  headerInfo <- c( # paste0("Name of this file: ", "NA"),
                   paste0("Name of this file: ", NCCAASCIIName),
                   paste0("Source file: ", "NA"),
                   paste0("Instrument: ", "Lafayette Windows"),
                   # paste0("Instrument: ", "Instrument Not Available"),
                   paste0("Software Version: ", "Software Version Not Available"),
                   paste0("Chart Date: ", "NA"),
                   paste0("Time: ", thisChartTime),
                   paste0("Examination Number: ", outputSeriesName2),
                   # paste0("Examination Number: 2"),
                   paste0("Chart Number: ", newChartName),
                   paste0("Number of questions: ", nrow(thisChartEventsDF)),
                   paste0("Fastest Sample Rate (Hz): ", "30"),
                   paste0("Number of samples: ", nrow(thisChartDF)),
                   paste0("Number of channels: ", length(outputSensors)),
                   paste0("Sample Rate (Hz) - UPneumo: ", "30"),
                   paste0("Sample Rate (Hz) - LPneumo: ", "30"),
                   paste0("Sample Rate (Hz) - EDA1: ", "30"),
                   paste0("Sample Rate (Hz) - Cardio1: ", "30"),
                   paste0("Sample Rate (Hz) - Move1: ", "30"),
                   if(isTRUE(inclPPG2)) paste0("Sample Rate (Hz) - PPG1: ", "30"),
                   if(isTRUE(inclAutoEDA)) paste0("Sample Rate (Hz) - EDA2: ", "30")
  )
  
  #### initialize a vector for the list of stimulus events ####
  
  {
    stimText <- rep("", times=(nrow(thisChartEventsDF)+1))
    
    stimText[1] <- "Event    Label Statement"
    n=1
    for(n in 1:(length(stimText)-1)) {
      stimText[(n+1)] <- paste( str_pad(str_pad(n, 2, side="left", pad="0"), 5, side="right"),
                                # str_pad(str_pad(thisChartEventsDF$Event[n], 2, side="left", pad="0"), 5, side="right"),
                                
                                ifelse(fixDuplicates, 
                                       str_pad(thisChartEventsDF$eventLabel[n], 8, side="left"),
                                       str_pad(thisChartEventsDF$Label[n], 8, side="left")),
                                ifelse(fixDuplicates,
                                       str_pad(thisChartEventsDF$eventLabel[n], 9, side="right"),
                                       str_pad(thisChartEventsDF$Label[n], 9, side="right")) 
                                
      ) 
    }
    
    # print(stimText)
  }
  
  #### initialize a vector for the event locations ####
  
  {
    # initialize a vector
    eventInfo <- rep("", times=(nrow(thisChartEventsDF)+1))
    
    eventInfo[1] <- "Event    Label      Begin        End     Answer"
    
    n=1
    for(n in 1:(length(eventInfo)-1)) {
      eventInfo[(n+1)] <- paste( str_pad(str_pad(n, 2, side="left", pad="0"), 5, side="right"),
                                 # str_pad(str_pad(thisChartEventsDF$Event[n], 2, side="left", pad="0"), 5, side="right"),
                                 
                                 ifelse(fixDuplicates, 
                                        str_pad(thisChartEventsDF$eventLabel[n], 8, side="left"),
                                        str_pad(thisChartEventsDF$Label[n], 8, side="left")),
                                 # str_pad(thisChartEventsDF$Label[n], 8, side="left"),
                                 
                                 str_pad(thisChartEventsDF$Begin[n], 10, side="left"),
                                 str_pad(thisChartEventsDF$End[n], 10, side="left"),
                                 str_pad(thisChartEventsDF$Answer[n], 10, side="left") 
                                 
      )
    }
    
    # View(thisChartEventsDF)
    # print(eventInfo)
  }
  
  #### initialize a data frame for the time series data ####
  
  {
    
    assign("thisChartDF", thisChartDF, envir=.GlobalEnv)
    # stop()
    
    # View(thisChartDF)
    
    {
      # select the data columns for output in the NCCA ASCII file
      
      SampleNUmber <- round(as.integer(thisChartDF$Sample), 0)
      # Time <- thisChartDF$Time
      
      if(fixDuplicates) {
        Label <- thisChartDF$eventLabel
      } else {
        Label <- thisChartDF$Label
      }
      
      UPneumo <- round(as.integer(thisChartDF$UPneumo), 0)
      LPneumo <- round(as.integer(thisChartDF$LPneumo), 0)
      EDA1 <- round(as.integer(thisChartDF$EDA1), 0)
      Cardio1 <- round(as.integer(thisChartDF$Cardio1), 0)
      Move1 <- round(as.integer(thisChartDF$Move1), 0)
      if(isTRUE(inclPPG2)) PPG1 <- round(as.integer(thisChartDF$PPG1), 0)
      if(isTRUE(inclAutoEDA)) EDA2 <- round(as.integer(thisChartDF$c_AutoEDA), 0)
      
      # use these to output the smoothed and filtered data
      # UPneumo <- round(as.integer(thisChartDF$c_UPneumoSm), 0)
      # LPneumo <- round(as.integer(thisChartDF$c_LPneumoSm), 0)
      # EDA1 <- round(as.integer(thisChartDF$c_AutoEDA), 0)
    }
    
    {
      ### Mar 8, 2021 calculate a new time scale
      
      chartTime <- fromMinSecFn(x=thisChartDF$Time, vct=FALSE)
      
      dataLength <- nrow(thisChartDF)
      
      # dataRate <- round(1 / (chartTime / dataLength))
      
      ## new time vector and new data rate ##
      
      # make a new time vector at the new data rate
      secondsVc <- round(seq(from=0.0, to=chartTime+1, by = .03333333), 2)
      # head(secondsVc)
      # tail(secondsVc)
      
      # trim the time vector
      secondsVc <- secondsVc[1:dataLength]
      
      newDataLength  <- length(secondsVc)
      # max(secondsVc)
      
      if(dataLength != newDataLength) stop("problem with output time scale")
      
      #  make a new time scale at the new data rate
      #  call the toMinSecFn() from the  toMinSec.R script
      Time <- toMinSecFn(secondsVc)
    }
    
    {
      # initialize a vector for the time series data frame
      examDAT <- rep("", times=(nrow(thisChartDF)+1))
      examDAT[1] <- 
        paste0("Sample     Time    Label", paste(str_pad(outputSensors, width=11, side="left"), collapse=""))
    }
    
    {
      # use a loop to add the text columns for the structured file output
      n=1
      for(n in 1:(length(examDAT)-1)) {
        examDAT[(n+1)] <- paste( str_pad(n, 6, side="left"),
                                 # str_pad(SampleNUmber[n], 6, side="left"),
                                 str_pad(str_sub(Time[n], 1, 8), 8, side="left"),
                                 str_pad(Label[n], 8, side="left", pad="-"),
                                 # now the time series data
                                 paste0(str_pad(as.integer(UPneumo[n]), 8, side="left"), ".0"),
                                 paste0(str_pad(as.integer(LPneumo[n]), 8, side="left"), ".0"),
                                 paste0(str_pad(as.integer(EDA1[n]), 8, side="left"), ".0"),
                                 paste0(str_pad(as.integer(Cardio1[n]), 8, side="left"), ".0"),
                                 paste0(str_pad(as.integer(Move1[n]), 8, side="left"), ".0"),
                                 if(isTRUE(inclPPG2)) paste0(str_pad(as.integer(PPG1[n]), 8, side="left"), ".0"),
                                 if(isTRUE(inclAutoEDA)) paste0(str_pad(as.integer(EDA2[n]), 8, side="left"), ".0") )
      }
    }
    
    # View(examDAT)
    # head(examDAT, 40)
    # tail(examDAT, 40)
    
  }
  
  #### write the NCCA ASCII output in the Lafayette format ####
  
  {
    # if(!exists("outputFolderName")) outputFolderName <- "NCCAASCIIOutput"
    
    # folderName <- paste0("FZCT_", str_sub(thisOutputName, -9, -7))
    
    writePFPathName <- paste0(outputFolderName,
                              "/",
                              NCCAASCIIName )
    
    # if(!dir.exists(folderName)) dir.create(folderName)
    
    writeLines(text=c(headerInfo, " ", stimText, " ", eventInfo, " ", examDAT), 
               con=writePFPathName)
  }
  
  #### output the name of the NCCA ASCII file ####
  
  # outputName <- paste0("D&-", 
  #                      examName, 
  #                      "_", 
  #                      chartFormat, 
  #                      "-", 
  #                      seriesName, 
  #                      ".", 
  #                      chartName)
  
  return(NCCAASCIIName)
  
} # end writeNCCAASCIIFn()
 



