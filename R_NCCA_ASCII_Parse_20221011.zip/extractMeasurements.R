# R script to make a data frame of measurements
# 
# input is a vector of exam names
# ouput is a data frame of measurements for each exam
#
####

# library(stringr)

# source(paste0(RPath, 'NCCAASCII_init.R'), echo=FALSE)


# need the getFirstLastEventFn() 
source(paste0(RPath, 'sigProcHelper.R'), echo=FALSE)



# get exam names from the _Data data frames
# uniqueExams <- unique(str_sub(ls(pattern="*_Data$", pos=1),1, -6))
# uniqueExams <- uniqueExams[1]




extractMeasurementsFn<- function(x=uniqueExams, writeCSV=FALSE, CSVName="") {
  # function to iterate over a vector of data frame names 
  # and make a data frame of all measurements
  # 6/16/2016
  # Raymond Nelson
  #
  # x input is a vector of names of data frames with time series data for all exams
  # 
  # output of the function will be a message indicating the number of exams processed
  ####
  
  uniqueExams <- x
  
  print("Extract measurements to a data frame")
  
  #### iterate over each exam in the list ####
  
  i=1
  for(i in 1:length(uniqueExams)) {
  
  	#### get the data for this exam ####
    
    {
      
      examName <- uniqueExams[i]
      # get the names of time series lists for all unique series in each exam
      searchString <- paste0("*", examName, "_Data", "*")
      examDF <- get(glob2rx(searchString, trim.head=TRUE, trim.tail=TRUE), pos=1)
      
      examDF$examName <- as.character(examDF$examName)
      examDF$seriesName <- as.character(examDF$seriesName)
      examDF$chartName <- as.character(examDF$chartName)
      
      examStartRow <- 1
      examEndRow <- nrow(examDF)
      
      # assign("examDF", examDF, pos=1)
      # assign("examName", examName, pos=1)
      
      if(showNames==TRUE) print(examName)
      
      # initialize the output data frame
      outputDF <- NULL
      
      # get the names of all unique series in the exam
      uniqueSeries <- as.character(unique(examDF$seriesName))
      
    }
    
    #### iterate over each unique series ####
    
    j=1
    for(j in 1:length(uniqueSeries)) {
      
      {
        
        seriesName <- uniqueSeries[j]
        # get the list of time series data for the charts in the exam
        seriesDF <- examDF[examDF$seriesName==seriesName,]
        
        # seriesOnsetRow <- range(which(examDF$seriesName==seriesName))[1]
        # seriesEndRow <- range(which(examDF$seriesName==seriesName))[2]
        seriesOnsetRow <- which(examDF$seriesName==seriesName)[1]
        seriesEndRow <- seriesOnsetRow + nrow(seriesDF) - 1
        
        # assign("seriesDF", seriesDF, pos=1)
        # assign("seriesName", seriesName, pos=1)
        
        if(showNames==TRUE) print(paste("series", seriesName))
        
        # uniqueCharts <- names(seriesDF)
        uniqueCharts <- as.character(unique(seriesDF$chartName))
        
      }
      
      #### iterate over each chart in the series ####
      
      k=1
      for(k in 1:length(uniqueCharts)) {
        
        {
          
          chartName <- uniqueCharts[k]
          # get the time series data frame for each chart in the series
          chartDF <- seriesDF[seriesDF$chartName==chartName,]
          # View(chartDF)
          
          chartOnsetRow <- which(seriesDF$chartName==chartName)[1]
          chartEndRow <- chartOnsetRow + nrow(chartDF) - 1
          
          # assign("chartDF", chartDF, pos=1)
          # assign("chartName", chartName, pos=1)
          
          print(paste("Chart:", chartName))
          
          # skip short charts less than 10 seconds
          if(nrow(chartDF)<600) next()
          
          # a vector of event onset rows
          Labels <- chartDF$Label[chartDF$eventLabel!=""]
          eventLabels <- chartDF$eventLabel[chartDF$eventLabel!=""]
          
          # 2-21-2019 do not exclude non-stim events
          # so the selectCQ function can consider these events
          # when selecting RQ/CQ pairs
          # Labels <- Labels[!(Labels %in% excludeEvents)]
          # eventLabels <- eventLabels[!(Labels %in% excludeEvents)]
          
          # advance to the next chart if no events
          if(length(eventLabels)==0) {
            print("no stimulus events")
            next()
          } 
          
          # get the first and last event indices
          firstEvent <- getFirstLastEventFn(x=chartDF)[1]
          lastEventEnd <- getFirstLastEventFn(x=chartDF)[2]
          
        }
        
        #### intialize a data frame to hold the output measurement table ####
        
        {  
          measurementsDF <- NULL
        }
        
        #### iterate over all the events in the chart data frame ####
        
        l=1
        for (l in 1:length(eventLabels)) {
       
          {
            
            # slice the segment time series data frame
            
            segment <- Labels[l]
            segmentName <- eventLabels[l]
            
            # get the onset row using the segment name so that events during the prestimSegment are ignored
            segOnsetRow <- which(chartDF$eventLabel==segmentName)[1]
            # stimSegOffset and answer are initialized a little bit later
            
            # set the end row using the evaluation window length 
            segEndRow <- segOnsetRow + measuredSeg*cps - 1
            if(segEndRow > nrow(chartDF)) segEndRow <- nrow(chartDF) - 1
            
            # get the segment prestim row
            prestimRow <- segOnsetRow - prestimSeg*cps
            if(prestimRow < 1) prestimRow <- 1
            
            # get the segment start row  in the segment DF
            startRow <- prestimRow
            
            # get the segment end row
            endRow <- segEndRow + addSeg*cps
            if(endRow > nrow(chartDF)) endRow <- nrow(chartDF)
            
            # # get the first offset and answer after the segment onset row
            # # offsetRow is the end of the stimulus question in the chartDF
            # # as opposed to the stimEndRow which is the end of the EW
            # # and the endRow which is the end of the segment + some added seconds
            # offsetRow <- which(chartDF$Events[segOnsetRow:nrow(chartDF)]=="offsetRow")[1] + segOnsetRow - 1
            # # offsetRow <- which(segmentDF$Events[stimOnsetRow:stimEndRow]=="offsetRow")[1]
            # if(is.na(offsetRow)) offsetRow <- stimEndRow - 2
            
            # answerRow <- which(chartDF$Events[segOnsetRow:nrow(chartDF)]=="answerRow")[1] + segOnsetRow - 1
            # # answerRow <- which(segmentDF$Events[stimOnsetRow:nrow(segmentDF)]=="answerRow")[1]
            # if(is.na(answerRow)) answerRow=stimEndRow - 1
            
            # fix problem when answerRow == offsetRow
            # if(offsetRow == stimOnsetRow) offsetRow <- stimOnsetRow + 1
            # if(answerRow <= offsetRow) answerRow <- offsetRow + 1
            # if(offsetRow >= nrow(segmentDF)) offsetRow <- nrow(segmentDF) - 2
            # if(answerRow >= nrow(segmentDF)) answerRow <- nrow(segmentDF) - 1
            
            # get the segment data frame
            segmentDF <- chartDF[startRow:endRow,]
            # View(segmentDF)
            
            assign("segmentDF", segmentDF, pos=1)
            assign("segmentName", segmentName, pos=1)
            
          }
          
          {
            
            # get the event rows in the segmentDF (not the chartDF)
            
            # if(segmentName == "R10") stop()
            
            # stimOnsetRow <- segOnsetRow - startRow + 1 # will normally set to 301
            stimOnsetRow <- prestimSeg*cps + 1 # normally 301 if the prestim is 10 sec
            # prestimRow <- prestimRow - startRow + 1 # this will set the prestim row to 1
            prestimRow <- 1
            # stimEndRow <- segEndRow - startRow + 1 # will normally set to 750
            stimEndRow <- stimOnsetRow + measuredSeg*cps - 1 # normally 750 if EW is 15 sec
            # adjust the rows so that row numbers refer to data in the segmentDF not the chartDF
            
            # get the first offset and answer after the segment onset row
            # offsetRow is the end of the stimulus question in the chartDF
            # as opposed to the stimEndRow which is the end of the EW
            # offsetRow <- which(segmentDF$Events[stimOnsetRow:stimEndRow]=="offsetRow")[1]
            offsetRow <- which(chartDF$Events[segOnsetRow:nrow(chartDF)]=="offsetRow")[1] + segOnsetRow - 1
            # 
            # if(is.na(offsetRow)) offsetRow <- stimEndRow - 2 
            if(is.na(offsetRow)) offsetRow <- stimEndRow - 2 + segOnsetRow - 1
            
            # answerRow <- which(segmentDF$Events[stimOnsetRow:nrow(segmentDF)]=="answerRow")[1]
            answerRow <- which(segmentDF$Events[stimOnsetRow:nrow(segmentDF)]=="answerRow")[1] + segOnsetRow - 1
            # if(is.na(answerRow)) answerRow=stimEndRow - 1 
            if(is.na(answerRow)) answerRow=stimEndRow - 1 + segOnsetRow - 1
            
            # set answer to "" if it is beyond the current segment + 5 seconds
            # it is likely to be the answer for the next stimulus 
            # because there is no answer to this segment
            if(answerRow > offsetRow + 5*cps) answerRow <- ""
            
            # fix problem when answerRow == offsetRow
            if(offsetRow == stimOnsetRow) offsetRow <- stimOnsetRow + 1
            if(answerRow <= offsetRow) answerRow <- offsetRow + 1
            
            if(showNames==TRUE) print(segmentName)
            
            # onsetRow <- which(segmentDF$Events=="onsetRow")[1]
            
            # get the stimulus onset row for the segment 
            # measurement information will be taken from this row
            # getRow <- cps * prestimSeg + 1
            getRow <- stimOnsetRow
            
            ####  set the warn level to supress warnings  ####
            
            oldw <- getOption("warn")
            options(warn = -1)
            
          }
          
          #### pneumo measurements ####
          
          {
            
            # get the measurements if numeric otherwise keep the text value
            P2 <- ifelse(is.na(as.numeric(segmentDF$UPneumoMeasure[getRow])),
                         as.numeric(segmentDF$UPneumoMeasure[getRow]),
                         as.numeric(segmentDF$UPneumoMeasure[getRow]) )
            names(P2) <- "UPneumo"
            P1 <- ifelse(is.na(as.numeric(segmentDF$LPneumoMeasure[getRow])),
                         as.numeric(segmentDF$LPneumoMeasure[getRow]),
                         as.numeric(segmentDF$LPneumoMeasure[getRow]) )
            names(P1) <- "LPneumo"
            
            # initialize a vector to combine the upper and lower pneumo scores 
            Pneumo <- NA
            names(Pneumo) <- "Pneumo"
            
          }
          
          #### EDA measurements ####
          
          {
            
            # EDA <- as.numeric(segmentDF$AutoEDAMeasure[which(as.numeric(segmentDF$AutoEDAMeasure)>0)][1])
            # EDA <- segmentDF$AutoEDAMeasure[as.numeric(segmentDF$AutoEDAMeasure)>0][1]
            # changed 1-17-2017 to prevent extraction of the subsequent measurement 
            
            AutoEDA <- segmentDF$AutoEDAMeasure[getRow]
            names(AutoEDA) <- "AutoEDA"
            AutoEDADuration <- segmentDF$AutoEDADuration[getRow]
            names(AutoEDADuration) <- "AutoEDADuration"
            AutoEDAComplexity <- segmentDF$AutoEDAComplexity[getRow]
            names(AutoEDAComplexity) <- "AutoEDAComplexity"
            
            ManualEDA <- segmentDF$ManualEDAMeasure[getRow]
            names(ManualEDA) <- "ManualEDA"
            ManualEDADuration <- segmentDF$ManualEDADuration[getRow]
            names(ManualEDADuration) <- "ManualEDADuration"
            ManualEDAComplexity <- segmentDF$ManualEDAComplexity[getRow]
            names(ManualEDAComplexity) <- "ManualEDAComplexity"
            
          }
          
          #### Cardio measurement ####
          
          {
            
            # Cardio <- as.numeric(segmentDF$CardioMeasure[which(as.numeric(segmentDF$CardioMeasure)>0)][1])
            # Cardio <- segmentDF$CardioMeasure[as.numeric(segmentDF$CardioMeasure)>0][1]
            # changed 1-17-2017 to prevent extraction of the subsequent measurement 
            
            Cardio <- segmentDF$CardioMeasure[getRow]
            names(Cardio) <- "Cardio"
            CardioDuration <- segmentDF$CardioDuration[getRow]
            names(CardioDuration) <- "CardioDuration"
            CardioComplexity <- segmentDF$CardioComplexity[getRow]
            names(CardioComplexity) <- "CardioComplexity"
            CardioRate <- segmentDF$CardioRate[getRow]
            names(CardioRate) <- "CardioRate"
            
          }
          
          #### forearm cuff / finger cuff measurement ####
          
          if( sum(pmatch(names(segmentDF), "FCMeasure", nomatch=0)) != 0 ) {
          
            # FC <- as.numeric(segmentDF$FCMeasure[which(as.numeric(segmentDF$FCMeasure)>0)][1])
            
            # FC <- segmentDF$FCMeasure[as.numeric(segmentDF$FCMeasure)>0][1]
            # changed 1-17-2017 to prevent extraction of the subsequent measurement 
            FC <- segmentDF$FCMeasure[getRow]
            names(FC) <- "FC" # if(length(FC) > 0) names(FC) <- "FC"
            FCDuration <- segmentDF$FCDuration[getRow]
            names(FCDuration) <- "FCDuration"
            FCComplexity <- segmentDF$FCComplexity[getRow]
            names(FCComplexity) <- "FCComplexity"
            FCRate <- segmentDF$FCRate[getRow]
            names(FCRate) <- "FCRate"
            
          }
          
          #### PLE measurement ####
          
          if(sum(pmatch(names(segmentDF), "PPG1Measure", nomatch=0))!=0) {
            
            # PLE <- as.numeric(segmentDF$PPG1Measure[which(as.numeric(segmentDF$PPG1Measure)>0)][1])
            # PLE <- segmentDF$PPG1Measure[as.numeric(segmentDF$PPG1Measure)>0][1]
            # changed 1-17-2017 to prevent extraction of the subsequent measurement 
            PLE <- segmentDF$PPG1Measure[getRow]
            if(length(PLE) > 0) names(PLE) <- "PLE"
              
          }
          
          #### aggregate the sensor measurements
          
          measurements <- c(P2, 
                            P1, 
                            Pneumo, 
                            AutoEDA, 
                            AutoEDADuration, 
                            AutoEDAComplexity,
                            ManualEDA,
                            ManualEDADuration,
                            ManualEDAComplexity,
                            Cardio,
                            CardioDuration,
                            CardioComplexity,
                            CardioRate,
                            if(sum(pmatch(names(segmentDF), "FCMeasure", nomatch=0))!=0) {
                              c(FC, FCDuration, FCComplexity, FCRate)
                            }, 
                            # eCardio, 
                            if(sum(pmatch(names(segmentDF), "PPG1Measure", nomatch=0))!=0) {
                              PLE
                            } )
          
          #### initialize some vectors for the _Measurement data frame ####
           
          {
            
            # rank scores
            rankScore <- rep("", times=length(measurements))
            # a vector to hold the name of the CQ selected for each RQ
            CQName <- rep("", times=length(measurements))
            # RRM scores
            RRMScore <- rep("", times=length(measurements))
            # Miritello rank scores
            miritelloRankScore <- rep("", times=length(measurements))
            # ipsative Z score (leave-one-out)
            ipZScore <- rep("", times=length(measurements))
            # R/C scores
            RCScore <- rep("", times=length(measurements))
            
            # OSS-3 scores
            OSS3Score <- rep("", times=length(measurements))
            # CQ mean for OSS-2 R/C ratio
            CQMean <- rep("", times=length(measurements))
            # OSS-2scores
            OSS2Score <- rep("", times=length(measurements))
            # probability analysis scores
            PAScore <- rep("", times=length(measurements))
            # integer scores
            ESSScore <- rep("", times=length(measurements))
            # ROSS scores
            ROSSScore <- rep("", times=length(measurements))
            # PSS scores
            PSSScore <- rep("", times=length(measurements))
            # bootstrap scores
            bootstrapScore <- rep("", times=length(measurements))
            
            #### PCAT scores ####
            
            PCATScore <- rep("", times=length(measurements))
            
          }
          
          
          #### Laplace smoothing ####
          
          # Laplace add 1 smoothing 
          # to ensure non-zero probabilities and allow division with non-response segments
          
          # commented out 2019-7-11
          # measurements <- measurements + 1
          
          
          
          
          
          ##### make a data frame of the measurements #####
          
          measurementDF1 <- cbind.data.frame(rep(examName, times=length(measurements)),
                                             rep(seriesName, times=length(measurements)),
                                             rep(chartName, times=length(measurements)),
                                             rep(segment, times=length(measurements)),
                                             rep(segmentName, times=length(measurements)),
                                             rep(segOnsetRow, times=length(measurements)),
                                             rep(offsetRow, times=length(measurements)),
                                             rep(answerRow, times=length(measurements)),
                                             sensorName=names(measurements),
                                             measurement=measurements,
                                             rankScore,
                                             RRMScore,
                                             miritelloRankScore,
                                             ipZScore,
                                             RCScore,
                                             CQName,
                                             ESSScore,
                                             OSS3Score,
                                             CQMean,
                                             OSS2Score,
                                             PAScore,
                                             ROSSScore,
                                             PSSScore,
                                             bootstrapScore,
                                             PCATScore )
          names(measurementDF1) <- c("examName", 
                                     "seriesName", 
                                     "chartName",
                                     "Label",
                                     "eventLabel", 
                                     "Begin",
                                     "End",
                                     "Answer",
                                     "sensorName", 
                                     "sensorMeasurement", 
                                     "rankScore", 
                                     "RRMScore",
                                     "miritelloRankScore",
                                     "ipZScore",
                                     "RCScore", 
                                     "CQName",
                                     "ESSScore",
                                     "OSS3Score",
                                     "CQMean",
                                     "OSS2Score",
                                     "PAScore",
                                     "ROSSScore",
                                     "PSSScore",
                                     "bootstrapScore",
                                     "PCATScore" )
                                            
          measurementsDF <- rbind.data.frame(measurementsDF, measurementDF1)
          
          # View(measurementsDF)
          # fix the column data types
          
          {
            measurementsDF$examName <- as.character(measurementsDF$examName)
            measurementsDF$seriesName <- as.character(measurementsDF$seriesName)
            measurementsDF$chartName <- as.character(measurementsDF$chartName)
            measurementsDF$Label <- as.character(measurementsDF$Label)
            measurementsDF$eventLabel <- as.character(measurementsDF$eventLabel)
            measurementsDF$sensorName <- as.character(measurementsDF$sensorName)
          }
          
          # sensor measurement is numeric
          
          {
            measurementsDF$sensorMeasurement <- 
              as.numeric(measurementsDF$sensorMeasurement, na.rm=TRUE)
            
            measurementsDF$rankScore <- as.character(measurementsDF$rankScore)
            measurementsDF$RRMScore <- as.character(measurementsDF$RRMScore)
            measurementsDF$miritelloRankScore <- 
              as.character(measurementsDF$miritelloRankScore)
            measurementsDF$ipZScore <- as.character(measurementsDF$ipZScore)
            measurementsDF$RCScore <- as.character(measurementsDF$RCScore)
            measurementsDF$CQName <- as.character(measurementsDF$CQName)
            measurementsDF$ESSScore <- as.character(measurementsDF$ESSScore)
            measurementsDF$OSS3Score <- as.character(measurementsDF$OSS3Score)
            measurementsDF$CQMean <- as.character(measurementsDF$CQMean)
            measurementsDF$OSS2Score <- as.character(measurementsDF$OSS2Score)
            measurementsDF$PAScore <- as.character(measurementsDF$PAScore)
            measurementsDF$ROSSScore <- as.character(measurementsDF$ROSSScore)
            measurementsDF$PSSScore <- as.character(measurementsDF$PSSScore)
            measurementsDF$bootstrapScore <- as.character(measurementsDF$bootstrapScore)
            measurementsDF$PCATScore <- as.character(measurementsDF$PCATScore)
          }
          
          #### reset the old warn level ####
          
          options(warn = oldw)
        
        } # end loop over l events 
        
        #### check respiration  for instability or desynchronization ####
        
        {
          # currently handled in the pneumoExtract.R script
        }
        
        #### check the upper and lower respiration for extreme values ####
        
        # { # commented out Sep 24, 2021
        #   
        #   # PRatio <- exp(abs(log(UPMeasurement / LPMeasurement)))
        #   
        #   upperRows <- which(measurementsDF$sensorName == "UPneumo")
        #   
        #   lowerRows <- which(measurementsDF$sensorName == "LPneumo")
        #   
        #   # exclude missing and zero values 
        #   
        #   upperRows <- 
        #     upperRows[which(measurementsDF$sensorMeasurement[upperRows] != 0)]
        #   
        #   lowerRows <- 
        #     lowerRows[which(measurementsDF$sensorMeasurement[lowerRows] != 0)]
        #   
        #   # get the respiration values
        #   
        #   upperVals <- measurementsDF$sensorMeasurement[upperRows]
        #   
        #   lowerVals <- measurementsDF$sensorMeasurement[lowerRows]
        #   
        #   # calculate the means
        #   
        #   upperMean <- 
        #     mean(upperVals, na.rm=TRUE)
        #   
        #   lowerMean <- 
        #     mean(lowerVals, na.rm=TRUE)
        #   
        #   # calculate the mean ratio
        #   # could use leave one out with a loop
        #   
        #   upperRatio <- exp(abs(log(upperMean / abs(upperVals))))
        #   
        #   lowerRatio <- exp(abs(log(lowerMean / abs(lowerVals))))
        #   
        #   exUpper <- which(upperRatio >= 1.25)
        #   
        #   exLower <- which(lowerRatio >= 1.25)
        #   
        #   # set the out of range vals to 0
        #   
        #   measurementsDF$sensorMeasurement[upperRows[exUpper]] <- 0
        #   measurementsDF$sensorMeasurement[lowerRows[exLower]] <- 0
        #   
        #   measurementsDF$sensorMeasurement[upperRows]
        #   
        #   measurementsDF$sensorMeasurement[lowerRows]
        #   
        #   
        #   
        # }
        
        outputDF <- rbind.data.frame(outputDF, measurementsDF)
        
        # View(measurementsDF)
        
      } # end iteration over k chart data frames 
      
    
    } # end iteration over j series data frames
    
    row.names(outputDF) <- NULL
    
    assign(paste(examName, "Measurements", sep="_"), outputDF, pos=1)
    
    if(writeCSV==TRUE) {
      write.csv(outputDF, file=paste0(examName, CSVName, "_Measurements", ".csv"), row.names=FALSE)
    }
      
  } # end iteration over i exams
  
  #### output ####
  
  if(showNames==TRUE) print(paste(i, "exams processed"))
  
  if(output==TRUE) return(outputDF)
  
} # end extractMeasurementsFn()

# extractMeasurementsFn(x=uniqueExams, showNames=TRUE, output=FALSE, CSVName="")


